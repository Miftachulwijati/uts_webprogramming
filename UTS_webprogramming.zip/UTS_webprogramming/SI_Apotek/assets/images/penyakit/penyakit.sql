-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 03, 2019 at 06:22 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_apotek`
--

-- --------------------------------------------------------

--
-- Table structure for table `penyakit`
--

CREATE TABLE `penyakit` (
  `id_penyakit` int(11) NOT NULL,
  `nama_penyakit` varchar(255) NOT NULL,
  `spesifikasi` text NOT NULL,
  `jenis_penyakit` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penyakit`
--

INSERT INTO `penyakit` (`id_penyakit`, `nama_penyakit`, `spesifikasi`, `jenis_penyakit`, `gambar`) VALUES
(1, 'Alergi Makanan', 'Alergi makanan terjadi ketika sistem kekebalan tubuh menganggap protein di dalam makanan merupakan suatu ancaman bagi tubuh. Sebagai bentuk respons, tubuh melepaskan senyawa kimia yang memicu reaksi alergi.\r\nReaksi yang timbul dari alergi makanan sering kali ringan. Namun pada beberapa kasus, alergi makanan bisa sampai mengancam nyawa. Oleh karena itu, penting untuk mengetahui cara mencegah dan meredakan reaksi alergi yang muncul.\r\nGejala Alergi Makanan\r\n\r\nPada sebagian orang, alergi makanan dapat menyebabkan penderitanya merasa tidak nyaman meski tidak terlalu parah. Gejala sering kali muncul dalam beberapa menit sampai dua jam setelah mengonsumsi makanan pemicu alergi.\r\n\r\nGejala alergi makanan yang muncul sama dengan reaksi alergi pada umumnya, yaitu:\r\n\r\n    Pilek atau hidung tersumbat.\r\n    Ruam kulit yang terasa gatal.\r\n    Gatal di mulut, tenggorokan, mata, dan di bagian tubuh lain.\r\n    Pembengkakan pada wajah, bibir, lidah, atau tenggorokan.\r\n    Sulit menelan dan berbicara.\r\n    Mengi atau bengek.\r\n    Sesak napas.\r\n\r\nPenderita alergi makanan juga dapat merasakan gejala di saluran pencernaan, seperti sakit perut, diare, mual, dan muntah.\r\nKapan harus ke dokter\r\n\r\nPeriksakan diri Anda atau anak Anda ke dokter bila muncul gejala di atas setelah mengonsumsi makanan tertentu. Beri tahu dokter mengenai makanan yang baru dikonsumsi.\r\n\r\nPada beberapa orang, alergi makanan dapat memicu reaksi alergi serius yang disebut anafilaksis. Berikan suntikan epinephrine dan segera ke IGD bila muncul gejala anafilaksis, seperti:\r\n\r\n    Jantung berdebar\r\n    Pusing dan pandangan gelap\r\n    Keringat dingin\r\n    Hilang kesadaran\r\n\r\nKonsultasikan dengan dokter anak mengenai kemungkinan anak terkena alergi dan hal yang perlu diwaspadai bila terdapat keluarga yang menderita penyakit alergi, seperti alergi makanan, asma, atau rinitis alergi.\r\n\r\nPenyebab Alergi\r\n\r\nAlergi makanan terjadi ketika sistem kekebalan tubuh keliru menganggap protein di dalam makanan tertentu sebagai ancaman bagi tubuh. Guna meresponsnya, tubuh melepaskan antibodi yang disebut imunoglobulin E (IgE), guna menetralisir pemicu alergi (alergen) di dalam makanan tersebut.\r\n\r\nKetika seseorang kembali mengonsumsi makanan tersebut meski hanya sedikit, IgE akan merangsang tubuh untuk mengeluarkan senyawa kimia yang disebut histamin ke aliran darah. Histamin inilah yang menyebabkan timbulnya gejala alergi.\r\n\r\nAlergi makanan biasanya berlangsung sejak masa kanak-kanak, tetapi kadang juga baru muncul ketika seseorang sudah dewasa. Makanan yang menyebabkan alergi cenderung berbeda pada orang dewasa dan anak-anak.\r\n\r\nPada orang dewasa, reaksi alergi bisa muncul setelah mengonsumsi makanan berikut:\r\n\r\n    Ikan\r\n    Kerang\r\n    Udang\r\n    Kepiting\r\n    Kacang-kacangan\r\n\r\nSedangkan pada anak-anak, makanan yang umum menyebabkan alergi antara lain:\r\n\r\n    Kacang\r\n    Gandum\r\n    Kedelai\r\n    Telur\r\n    Susu sapi\r\n\r\nBelum diketahui mengapa pada beberapa kasus, alergi makanan baru muncul saat usia dewasa.\r\nFaktor Risiko Alergi Makanan\r\n\r\nAlergi makanan lebih berisiko dialami oleh orang yang menderita alergi lain, seperti rinitis alergi atau asma. Orang yang sudah terkena alergi pada satu jenis makanan juga lebih rentan menderita alergi pada jenis makanan lain.\r\n\r\nFaktor lain yang dapat meningkatkan risiko seseorang terserang alergi makanan adalah:\r\n\r\n    Berusia di bawah lima tahun.\r\n    Memiliki keluarga yang menderita riwayat alergi, seperti biduran atau asma.\r\n\r\nDiagnosis Alergi Makanan\r\n\r\nUntuk menentukan alergi makanan, dokter menanyakan gejala yang dialami pasien, makanan apa yang dikonsumsi sebelum gejala muncul, serta riwayat kesehatan pasien dan keluarganya. Setelah itu, pemeriksaan fisik akan dilakukan untuk membedakan gejala alergi makanan dengan gejala pada kondisi lain.\r\n\r\nSelanjutnya, dokter akan menjalankan tes alergi yang meliputi:\r\nTes alergi kulit\r\n\r\nDalam tes alergi pada kulit, kulit pasien akan ditusuk dengan jarum kecil. Setelah itu, dokter akan memasukkan sedikit protein pada makanan yang diduga menyebabkan alergi ke area kulit yang ditusuk tadi untuk melihat reaksinya.\r\nTes darah\r\n\r\nSampel darah pasien akan diambil untuk mengukur kadar imunoglobulin E (IgE) spesifik. Bila kadar IgE yang terkait makanan tertentu cukup tinggi dalam darah pasien, artinya pasien memiliki alergi terhadap makanan tersebut.\r\nTes makanan\r\n\r\nPasien akan diminta menghindari jenis makanan yang diduga menjadi penyebab alergi selama 1-2 minggu. Jika pasien alergi terhadap jenis makanan tadi, maka dalam kurun waktu tersebut pasien tidak akan mengalami reaksi alergi, dan akan kembali mengalaminya bila makanan tersebut kembali dikonsumsi.\r\n\r\nDokter juga dapat meminta pasien mengonsumsi makanan yang dicurigai sebagai pemicu alergi dalam porsi kecil, kemudian porsinya ditingkatkan secara perlahan. Jika tidak muncul reaksi alergi selama tes berlangsung, maka pasien diperbolehkan mengonsumsi makanan tersebut.\r\nPengobatan Alergi Makanan\r\n\r\nCara terbaik untuk mengatasi alergi makanan adalah dengan menghindari makanan penyebab alergi. Meski demikian, seseorang mungkin saja mengonsumsi makanan tersebut secara tidak sengaja. Bila hal ini terjadi, ada beberapa obat yang bisa digunakan untuk meredakan gejala.\r\n\r\nJika gejala yang muncul tergolong ringan, penderita bisa menggunakan antihistamin yang dijual bebas. Bila gejala masih terasa, penderita bisa ke dokter agar diberikan antihistamin dengan dosis lebih tinggi.\r\n\r\nBila muncul gejala anafilaksis, penderita harus dibawa ke IGD rumah sakit untuk diberikan suntikan epinephrine. Setelah gejala hilang, dokter akan meminta pasien untuk selalu membawa suntikan tersebut.\r\n\r\nPenting untuk memahami cara menggunakan suntik epinephrine, bila gejala alergi makanan yang Anda alami cukup parah. Selain itu, ajari juga orang-orang yang sering berada di dekat Anda, misalnya keluarga atau rekan kerja, mengenai cara menggunakan suntikan tersebut bila Anda terserang anafilaksis.\r\n\r\nPastikan untuk mengganti epinephrine sebelum masa kedaluwarsa, dan ganti alat suntiknya bila sudah tidak berfungsi dengan baik.\r\nKomplikasi Alergi Makanan\r\n\r\nPada kasus yang parah, alergi makanan dapat menyebabkan anafilaksis, yaitu reaksi alergi yang dapat berbahaya. Anafilaksis dapat berlangsung beberapa menit bahkan detik setelah terpapar pemicu alergi.\r\nPencegahan Alergi Makanan\r\n\r\nCara mencegah reaksi alergi makanan adalah dengan menghindari makanan yang dapat memicu alergi. Hal ini mungkin sedikit merepotkan bagi penderita, tetapi tetap perlu dilakukan untuk menghindari kondisi yang lebih serius.\r\n\r\nLakukan langkah-langkah berikut ini guna mencegah reaksi akibat alergi makanan:\r\n\r\n    Baca kandungan apa saja yang terdapat pada tiap kemasan makanan yang hendak dikonsumsi.\r\n    Bawa makanan ringan bebas alergi jika ingin ke luar rumah. Hal ini akan membantu bila Anda sulit menemukan makanan bebas alergi\r\n    Bila ingin makan di restoran, beritahu pelayan atau juru masak tentang makanan apa saja yang tidak boleh dikonsumsi.\r\n    Pastikan makanan yang dibeli di luar tidak diolah dan disajikan di tempat yang sebelumnya digunakan untuk mengolah makanan pemicu alergi.\r\n\r\nAnda juga perlu mengenakan gelang khusus yang mencantumkan bahwa Anda menderita alergi makanan. Gelang ini akan membantu saat muncul reaksi alergi dan Anda kesulitan untuk berkomunikasi. Bila reaksi alergi makanan cukup parah, konsultasikan dengan dokter tentang perlunya membawa suntik epinephrine.', 'Kulit', 'alergi-makanan.jpg'),
(2, 'Demam Bedarah (DBD)', 'Demam berdarah atau demam berdarah dengue (DBD) adalah penyakit yang disebabkan oleh infeksi virus Dengue. Virus ini masuk ke dalam tubuh manusia melalui gigitan nyamuk Aedes aegypti dan Aedes albopictus, yang hidup di wilayah tropis dan subtropis. Diperkirakan terdapat setidaknya 50 juta kasus demam berdarah di seluruh dunia tiap tahunnya.\r\nMenurut data yang dihimpun Kementerian Kesehatan Republik Indonesia, demam berdarah telah menjadi penyakit endemik di Indonesia sejak tahun 1968. Sejak itu, penyakit ini menjadi salah satu masalah utama di Indonesia, dengan penyebaran dan jumlah penderita yang cenderung meningkat setiap tahun.\r\n\r\nSepanjang 2017, diketahui ada sekitar 59.000 kasus demam berdarah di seluruh Indonesia, dengan lebih dari 400 kasus di antaranya berakhir dengan kematian. Karena jumlah penduduknya yang juga banyak, Provinsi Jawa Tengah dan Jawa Timur, menyumbang kasus DBD terbanyak untuk tahun 2017, yaitu lebih dari 7000 kasus di masing-masing provinsi.', 'demam', 'dbd.jgp');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `penyakit`
--
ALTER TABLE `penyakit`
  ADD PRIMARY KEY (`id_penyakit`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
