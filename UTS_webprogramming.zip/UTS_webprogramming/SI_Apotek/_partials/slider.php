<?php 

include './koneksi.php';
$slide = mysqli_query($conn, "SELECT * FROM tb_slide LIMIT 1");
$slider = mysqli_query($conn, "SELECT * FROM tb_slide WHERE id_slide != 1");
$data = mysqli_fetch_assoc($slide);


 ?>
<div id="carouselExampleControls" class="carousel slide shadow" data-ride="carousel">
  <div class="carousel-inner">

    <div class="carousel-item active">
      <img class="d-block w-100" style="height: 400px;" src="./assets/images/sliders/<?php echo $data['slide']; ?>" alt="First slide">
      <div class="carousel-caption">
          <h1>
            <?php echo $data['title']; ?>
          </h1>
            <p><?php echo $data['textslide']; ?></p>
        </div>
    </div>

    <?php while ($dt = mysqli_fetch_assoc($slider)) { ?>
    <div class="carousel-item">
      <img class="d-block w-100" style="height: 400px;" src="./assets/images/sliders/<?php echo $dt['slide']; ?>" alt="Second slide">
      <div class="carousel-caption">
          <h1>
            <?php echo $dt['title']; ?>
          </h1>
            <p><?php echo $dt['textslide']; ?></p>
        </div>
    </div>
  <?php } ?>


  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
