<?php 
    include './koneksi.php';
    $kontak = mysqli_query($conn, "SELECT * FROM contact");
    $logo = mysqli_query($conn, "SELECT * FROM tb_gambar");
    $lg = mysqli_fetch_assoc($logo);
 ?>
<header>
    <?php while ($data = mysqli_fetch_assoc($kontak)) { ?>


<nav class="navbar navbar-expand-lg">   
    
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigasi" aria-controls="navigasi" aria-expanded="false"aria-label="Toggle navigation"><i class="fas fa-align-justify"></i>
    </button>
    <div class="collapse navbar-collapse" id="navigasi">  
        <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
            <img style="width: 140px" src="./assets/images/<?php echo $lg['logo'] ?>">   
            <li class="nav-item">
                <a href="index.php" class="nav-link">HOME<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a href="index.php?page=profil" class="nav-link">PROFIL</a>
            </li>
            <li class="nav-item">
                <a href="index.php?page=jp" class="nav-link">GEJALA SAKIT</a>
            </li>
            <li class="nav-item">
                <a href="index.php?page=mcm_obat" class="nav-link">MACAM - MACAM OBAT</a>
            </li>
            <li class="nav-item">
                <a href="index.php?page=tips" class="nav-link">TIPS HIDUP SEHAT</a>
            </li>
            <li class="nav-item">
                <a href="index.php?page=contact" class="nav-link">CONTACT US</a>
            </li>
        </ul>
        
        <ul class="nav navbar-nav navbar-right navbar-user">
            <li class="dropdown user-dropdown mr-5">
                <?php if (isset($_SESSION['level'])): ?>
              <a style="color: white;" href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $_SESSION['username']; ?></a>
              <ul class="dropdown-menu" style="background-color: #008080; border: none;">
                <?php if($_SESSION['level']=='admin'){?>
                    <li><a class="nav-link fas fa-database" href="./admin/index.php"> Dashboard </a></li>
                <?php } else{?>
                    <li hidden><a class="nav-link fas fa-database">Dashboard </a></li>
                <?php } ?>
                <li><a class="nav-link fas fa-sign-in-alt" href="./content/logout.php"> LOGOUT</a></li>
            <?php else : ?>
                <li><a class="nav-link fas fa-sign-in-alt" href="./content/login.php"> LOGIN</a></li>   
            <?php endif ?>
              </ul>

    
</nav>
<?php } ?>
</header>
            