<?php 
	include './koneksi.php';
	$kontak = mysqli_query($conn, "SELECT * FROM contact");
	$profil = mysqli_query($conn, "SELECT * FROM data_profilweb LIMIT 1");
	$dt = mysqli_fetch_assoc($profil);
 ?>

<div class="footer">
	<div class="container-fluid">
	<div class="row">
		<?php while ($data = mysqli_fetch_assoc($kontak)) { ?>
		<div class=" col-md-5 col-sm-6 mt-3">
			<h4>Tentang Kami</h4>			
				<p><?php echo $dt['profil'] ?></p>
		</div>
		<div class="col-md-3 col-sm-6 mt-3">
			<div class="">
				<h4>Lihat Kami Di</h4>
					<div class="fa-2x">
						<a target="new" href="<?php echo $data['facebook'] ?>" class="nav-link2 fab fa-facebook-square"></a>
						<!-- <a class="fab fa-twitter-square"></a> -->
						<a target="new" href="https://wa.me/<?php echo $data['whatsapp'] ?>" class="nav-link2 fab fa-whatsapp"></a>
						<a target="new" href="<?php echo $data['instagram'] ?>" class="nav-link2 fab fa-instagram"></a>					
					</div>
			</div>				
		</div>
		<div class="col-md-4 col-sm-6 mt-3 mb-2">
			<h4>Contact</h4>
				<div>
					<span>Please contact Us below for more detail information.</span><br>
						<a target="new" href="https://wa.me/<?php echo $data['whatsapp']; ?>" class="nav-link2 fas fa-phone-alt mr-2 mb-2"></a><span><?php echo $data['whatsapp'] ?></span><br>
						<a target="new" href="<?php echo $data['link_location'] ?>" class="nav-link2 fas fa-home mb-2 mr-2"></a><span><?php echo $data['location'] ?></span>
				</div>
		</div>	
	<?php } ?>
	</div>
</div>
	<!-- .container -->
</div>
<div class="footer1 py-2">
	<p class="m-0 text-center text-white">Copyright &copy 2019-ApotekMAT</p>
</div>
<!-- Bootstrap core JavaScript -->
<script src="./assets/js/jquery.min.js"></script>
<script src="./assets/js/bootstrap.min.js"></script>
<script src="./assets/fontawesome-free/js/fontawesome.js"></script>
<script src="./assets/js/script.js"></script>
<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>