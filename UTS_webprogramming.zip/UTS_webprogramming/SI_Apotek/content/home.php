<header>
	<?php 
	include './koneksi.php';
	require '_partials/slider.php';
	echo "<br>";
	require 'profil.php';
	echo "<br>";
	$penyakit = mysqli_query($conn, "SELECT * FROM penyakit ORDER BY nama_penyakit ASC LIMIT 3");
	$obat = mysqli_query($conn, "SELECT * FROM obat ORDER BY nama_obat ASC LIMIT 3");
	 ?>

<div class="product" id="product">
	<div class="header">
		<a class="text-h1"><center>Gejala Sakit</center></a>
	</div>
	
	<div class="container">
		
		<div class="row justify-content-center">
			<?php while ($data = mysqli_fetch_assoc($penyakit)) { ?>	
			<div class="col-md-4 col-sm-12 mt-5">
				<div class="card shadow" style="width: 20rem;">
					<div class="inner">
						<img class="card-img-top" style="height: 200px;" src="./assets/images/penyakit/<?php echo $data['gambar']; ?>" alt="Card image cap">
					</div>
					<div class="card-body">
					    <h5 class="card-title"><strong><?php echo $data['nama_penyakit']; ?></strong></h5>
					    <p class="card-text"><?php echo $data['spesifikasi']; ?></p>
					    <a href="index.php?page=detail_penyakit&id=<?php echo $data['id_penyakit']; ?>" class="btn btn-success" data-value="detail_produk">View All</a>
					</div>
				</div>
			</div>
			<?php } ?>
		</div>
		<div class="mt-5 row justify-content-center">
			<a href="index.php?page=jp" class="btn btn-success">View All Gejala Sakit</a>	
		</div>
	</div>
	<br>
	<div class="header">
		<a class="text-h1"><center>Macam - Macam Obat</center></a>
	</div>
	<div class="container">
		<div class="row justify-content-center">
			<?php while ($data = mysqli_fetch_assoc($obat)) { ?>	
			<div class="col-md-4 col-sm-12 mt-5">
				<div class="card shadow" style="width: 20rem;">
					<div class="inner">
						<img class="card-img-top" style="height: 200px;" src="./assets/images/obat/<?php echo $data['gambar']; ?>" alt="Card image cap">
					</div>
					<div class="card-body">
					    <h5 class="card-title"><strong><?php echo $data['nama_obat']; ?></strong></h5>
					     <div class="price-box orange">
					    	
							<span>Rp. <?php echo number_format($data['harga_jual']); ?> / <?php echo $data['satuan'] ?></span>
					
						</div>
					    <p class="card-text"><?php echo $data['spesifikasi']; ?></p>
					    <a href="index.php?page=detail_obat&id=<?php echo $data['id_obat']; ?>" class="btn btn-success" data-value="detail_produk">View All</a>
					</div>
				</div>
			</div>
			<?php } ?>
		</div>

		<div class="mt-5 row justify-content-center">
			<a href="index.php?page=mcm_obat" class="btn btn-success">View All Macam - Macam Obat</a>	
		</div>
		<br>
		

	</div>

</div>

	
</header>
<!-- isi -->