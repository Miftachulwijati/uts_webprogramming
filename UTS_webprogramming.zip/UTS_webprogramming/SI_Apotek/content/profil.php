<?php 
	include './koneksi.php';
	$kontak = mysqli_query($conn, "SELECT * FROM data_profilweb LIMIT 1");
 ?>

<div class="profil">

	<div class="body container-fluid">
		<div class="text-h1 pt-4">
			<center>Who We Are?</center>
		</div>
		
		<div class="body container">
			<?php while ($data = mysqli_fetch_assoc($kontak)) { ?>
			<br>

			<center><p><?php echo $data['profil']; ?></p></center>
			<div class="card-group mt-5">

				<div class="card m-2" style="background-image: linear-gradient(#008080, #008059); border:3px solid #00baba; border-radius: 10px; color: white;">
					<div class="text-h2">
						<center>VISI</center>	
					</div>
					<div class="card-body">
			           	<p><?php echo nl2br(str_replace('', '', htmlspecialchars($data['visi']))); ?></p>
			        </div>
				</div>

				<div class="card m-2" style="background-image: linear-gradient(#008080, #008059); border:3px solid #00baba; border-radius: 10px; color: white;">
					<div class="text-h2">
						<center>MISI</center>	
					</div>
			        <div class="card-body">
			          	<p><?php echo nl2br(str_replace('', '', htmlspecialchars($data['misi']))); ?></p>
			        </div>
        			
				</div>
					
			</div>
			<?php } ?>
		</div>		
	</div>

	<br>
	<div class="body2 container-fluid" style="background-color: white; border-top: 2px solid black">
		<div class="text-h1 mt-5">
			<center>Why Choose Us?</center>
		</div>
		<div class="row">
			<div class="col-12 col-md-4 mb-2">
				<div class="card">
					<img src="./assets/images/tandatanya.jpg" width="100%">
				</div>
			</div>

		
			
			<div class="col-12 col-md-8">
			<div class="card">
				<div class="row container-fluid">			
					<div class="col-lg-6 col-md-6 col-sm-12 mb-5 item">
						<div class="icon fa-2x rotate">
								<center><i class="fas fa-star-half-alt pt-3"></i></center>
							</div> 
				           	<div class="text">
				            	<h5><strong>High Quality</strong></h5>
				            	<p>Mirum est notare quam littera gIt is a long established fact that a reader will content of a distracted admin. </p>
				            </div>
	        			
					</div>

					<div class="col-lg-6 col-md-6 col-sm-12 mb-5 item">
						<div class="icon fa-2x rotate">
								<center><i class="fas fa-edit pt-3"></i></center>
							</div>
				            <div class="text">
				            	<h5><strong>Easy To Use</strong></h5>
				            	<p>Mirum est notare quam littera gIt is a long established fact that a reader will content of a distracted admin.</p>
				            </div>
	        			
					</div>


					<div class="col-lg-6 col-md-6 col-sm-12 mb-5 item">
							<div class="icon fa-2x rotate">
								<center><i class="fas fa-hand-holding-usd pt-3"></i></center>
							</div>
						
							
				            <div class="text">
				            	<h5><strong>Choose your price</strong></h5>
				            	<p>You determine the price for your place. We provide devices to determine prices based on your location.</p>
				            </div>
	        			
					</div>

					<div class="col-lg-6 col-md-6 col-sm-12 mb-5 item">
						<div class="icon fa-2x rotate">
								<center><i class="fas fa-cogs pt-3"></i></center>
							</div>
				            <div class="text">
				            	<h5><strong>Service</strong></h5>
				            	<p>24Hours at service</p>
				            </div>
	        			
					</div>

				
				</div>
			</div>
			</div>
		
		</div>		
	</div>

</div>


<!-- <div class="body container-fluid">
		<div class="text-h1 pt-4">
			<center>Who We Are?</center>
		</div>
		<div class="body container">
			<?php while ($data = mysqli_fetch_assoc($kontak)) { ?>
			<br>
			<center><p><?php echo $data['profil']; ?></p><br></center>
			<div class="row container-fluids">

				<div class="col-lg-6 col-md-6 col-sm-12 mb-5 item">
					 <div class="content">
            			<div class="img">
                			<img src="./assets/images/cover.jpg">
            			</div>
			            <div class="text">
			            	<h5><?php echo $data['visi']; ?></h5>
			            </div>
        			</div>
				</div>

				<div class="col-lg-6 col-md-6 col-sm-12 mb-5 item">
					<div class="content">
            			<div class="img">
                			<img src="./assets/images/cover.jpg">
            			</div>
			            <div class="text">
			            	<h5><?php echo nl2br(str_replace('', '', htmlspecialchars($data['misi']))); ?></h5>
			            </div>
        			</div>
				</div>
				
			</div>
			<?php } ?>
		</div>		
	</div> -->