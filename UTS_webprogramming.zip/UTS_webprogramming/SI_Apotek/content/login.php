<?php 

require '../koneksi.php';
 
 ?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <meta name="viewport" content="width=device-width , initial-scale=1">
    <link rel="stylesheet" href="../assets/css/style.css">
  </head>
  <body id="login">

      <div class="center">
        <h2>LOGIN</h2> 
        
        <?php 
        if(isset($_GET['pesan'])){
          if($_GET['pesan']=="gagal"){
            echo "<div class='alert'>Username dan Password tidak sesuai !</div>";
          }
        }
        ?>
          
          <form action="../content/cek_sesi.php" class="fl" action="" method="post">
            <input class="itpw" type="text" name="username" autocomplete="off" placeholder="Username / Email"><br>
            <input class="itpw" type="password" name="password" placeholder="Password"><br>
            <input class="its" type="submit" name="login" value="LOGIN">
          </form>

      </div>

  </body>
</html>
