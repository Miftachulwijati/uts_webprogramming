<?php 
		include './koneksi.php';
		$detail = mysqli_query($conn, "SELECT * FROM tips");
		$no = 1;
 ?>

<title>Tips Hidup Sehat</title>

<div class="detail-product">
	<div class="container">
		<br>	
		<div class="text-h1">
			<center>Tips Hidup Sehat</center>
		</div>
		<br>
		<?php while ($data = mysqli_fetch_assoc($detail)) { ?>
		
		<p class="text-h3"><?php echo $no++; ?>. <?php echo $data['judul']; ?></p>
		<p><?php echo nl2br(str_replace('', '', htmlspecialchars($data['isi']))) ?></p>

	<?php } ?>
	<br>
	</div>
</div>