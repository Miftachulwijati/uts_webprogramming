<?php 
		include './koneksi.php';
		// $detail = mysqli_query($conn, "SELECT * FROM jenis_penyakit WHERE id_jp = '$_GET[id]'");
		$detail = mysqli_query($conn, "SELECT * FROM obat WHERE id_obat = '$_GET[id]'");
		$judul = mysqli_query($conn, "SELECT * FROM obat WHERE id_obat = '$_GET[id]'");
		$jd = mysqli_fetch_assoc($judul);
 ?>

<title><?php echo $jd['nama_obat']; ?></title>

<div class="detail-content">
	<div class="container">
		<?php while ($data = mysqli_fetch_assoc($detail)) { ?>
		<div class="text-h1">
			<center><?php echo $data['nama_obat']; ?></center>
		</div>
		<br>
		<div class="price-box2 orange">
			<span>Rp. <?php echo number_format($data['harga_jual']); ?> / <?php echo $data['satuan'] ?></span>
		</div>
		<center><img class="card-img-top" style="width: 50%;" src="./assets/images/obat/<?php echo $data['gambar']; ?>" alt="Card image cap"></center>
		<br>
		<p><?php echo nl2br(str_replace('', '', htmlspecialchars($data['spesifikasi']))) ?></p>

	<?php } ?>
	</div>
</div>