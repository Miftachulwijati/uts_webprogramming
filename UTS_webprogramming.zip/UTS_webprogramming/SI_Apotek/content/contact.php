<?php 
	include './koneksi.php';
	$kontak = mysqli_query($conn, "SELECT * FROM contact");
 ?>

<div class="contact">
	<div class="container">
		<br>
			<div class="text-h1">
				<center>CONTACT US</center>
			</div>

			<?php while ($data = mysqli_fetch_assoc($kontak)) { ?>
			<div class="row pb-4 justify-content-center" style="text-align:center;">

				<div class="col-md-4 mt-4">	
					<a href="<?php echo $data['link_location'] ?>" target="new" class="nav-link">
					<div class="card2">
		  				<div class="card-header">
		  					<center><p class="fas fa-home mb-2 mr-2"></p> Location</center>
		  				</div>
			  			<div class="card-body" style="height: 150px;">
						    <p><?php echo $data['location'] ?></p>
			  			</div>
					</div>
					</a>
				</div>


				<div class="col-md-4 mt-4">
					<a target="new" class="nav-link">
					<div class="card2">
		  				<div class="card-header">
		  					<center><p class="fas fa-envelope mb-2 mr-2"></p>Email</center>
		  				</div>
			  			<div class="card-body" style="height: 150px;">
						    <p class="text"><?php echo $data['email'] ?></p>
			  			</div>
					</div>	
					</a>
				</div>

				<div class="col-md-4 mt-4">
					<a href="https://wa.me/<?php echo $data['whatsapp'] ?>" target="new" class="nav-link">
					<div class="card2">
		  				<div class="card-header">
		  					<center><p class="fas fa-phone-alt mb-2 mr-2"></p>Call Us</center>
		  				</div>
			  			<div class="card-body" style="height: 150px;">
						    <p><?php echo substr_replace($data['whatsapp'], '0', 0,2) ?></p>
			  			</div>
					</div>
					</a>
				</div>

				<div class="col-md-4 mt-4 fa-8x">
					<a href="<?php echo $data['facebook'] ?>" target="new" class="nav-link">
						<div class="card2">
							<i class="fab fa-facebook-square mb-2 mr-2"></i>
						</div>
					</a>
				</div>


				<div class="col-md-4 mt-4 fa-8x">
					<a href="<?php echo $data['instagram'] ?>" target="new" class="nav-link">
						<div class="card2">
					    	<i class="fab fa-instagram mb-2 mr-2"></i>
						</div>
					</a>
				</div>



				
			</div>

				
				<!-- <div class="card bg-light mb-3" style="max-width: 18rem;">
		  			<div class="card-header">Header</div>
		  			<div class="card-body">
					    <h5 class="card-title">Light card title</h5>
					    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
		  			</div>
				</div>

				<div class="card bg-light mb-3" style="max-width: 18rem;">
		  			<div class="card-header">Header</div>
		  			<div class="card-body">
					    <h5 class="card-title">Light card title</h5>
					    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
		  			</div>
				</div>

				<div class="card bg-light mb-3" style="max-width: 18rem;">
		  			<div class="card-header">Header</div>
		  			<div class="card-body">
					    <h5 class="card-title">Light card title</h5>
					    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
		  			</div>
		  		</div>

		  		<div class="card bg-light mb-3" style="max-width: 18rem;">
		  			<div class="card-header">Header</div>
		  			<div class="card-body">
					    <h5 class="card-title">Light card title</h5>
					    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
		  			</div>
		  		</div>
 -->
	



		<!-- <br>
		<div class="address-holder right">
			<?php while ($data = mysqli_fetch_assoc($kontak)) { ?>
			<div class="social">
				<div class="fa-4x">
					<a class="fab fa-facebook-square" href=<?php echo $data['facebook'] ?> target="new" style="color: white"></a>
					<br>
					<a class="fab fa-whatsapp" href=<?php echo $data['link_whatsapp'] ?> target="new" style="color: white"></a>
					<br>
					<a class="fab fa-instagram" href=<?php echo $data['instagram'] ?> target="new" style="color: white"></a>
					<br>
				</div>
			</div>
			<div class="address">
					<h4><a class="fas fa-phone-alt" href=<?php echo $data['link_whatsapp'] ?> style="color: white"> <?php echo $data['whatsapp'] ?></a></h4>
					<br>
					<h4><a class="fas fa-envelope" href=<?php echo $data['facebook'] ?> style="color: white"> <?php echo $data['email'] ?></a></h4>
					<br>
					<h4><a class="fas fa-home" href=<?php echo $data['link_location'] ?> style="color: white"> <?php echo $data['location'] ?></a></h4>
				</div>
			</div>
		<?php } ?>
		</div> -->
		<?php } ?>

	</div>
</div>