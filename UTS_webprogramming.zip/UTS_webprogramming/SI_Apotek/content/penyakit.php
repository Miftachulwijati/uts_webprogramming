<?php 

	require './koneksi.php';

 ?>

<div class="product" id="product">
	<div class="container">
		<div class="header">
			<br>
			<a class="text-h1"><center>GEJALA PENYAKIT</center></a>
			
			<form method="post" action="" class="form-inline" style="float: center;">
	      		<input class="form-control col-md-11 mr-sm-12 m-2" type="search" name="txtsearch" autocomplete="off" placeholder="Search" aria-label="Search">
	<!--       		<input type="submit" value="Cari" name="submit1"> -->
	      		<button type="submit" class="btn2 mr-sm-2 m-2" name="submit1"><i class="fas fa-search"></i></button>
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="A" name="A">A</button>
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="B" name="B">B</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="C" name="C">C</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="D" name="D">D</button>  
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="E" name="E">E</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="F" name="F">F</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="G" name="G">G</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="H" name="H">H</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="I" name="I">I</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="J" name="J">J</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="K" name="K">K</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="L" name="L">L</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="M" name="M">M</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="N" name="N">N</button>
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="O" name="O">O</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="P" name="P">P</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="Q" name="Q">Q</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="R" name="R">R</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="S" name="S">S</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="T" name="T">T</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="U" name="U">U</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="V" name="V">V</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="W" name="W">W</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="X" name="X">X</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="Y" name="Y">Y</button> 
	      		<button type="submit" class="btn2 mr-sm-2 m-2" value="Z" name="Z">Z</button>  

	      		<!-- <?php
					$s = 'A';
					while($s != 'Z')
					{ ?>
					        <button type="submit" class="btn2 mr-sm-2 m-2" value="<?php echo $s; ?>" name="<?php echo $s; ?>"><?php echo $s; ?></button>
					<?php
					        $s = chr(ord($s) + 1);
					} ?>
					<button type="submit" class="btn2 mr-sm-2 m-2" value="<?php echo $s; ?>" name="<?php echo $s; ?>"><?php echo $s; ?></button> -->
 
	   		</form>
	   		<?php 

	   		if (isset($_POST['submit1'])) {
	   				$search = $_POST['txtsearch'];
	   				$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '%".$search."%' ORDER BY nama_penyakit ASC");

	   		}else if (isset($_POST['A'])) {
	   			$jp = $_POST['A'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['B'])) {
	   			$jp = $_POST['B'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['C'])) {
	   			$jp = $_POST['C'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['D'])) {
	   			$jp = $_POST['D'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['E'])) {
	   			$jp = $_POST['E'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['F'])) {
	   			$jp = $_POST['F'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['F'])) {
	   			$jp = $_POST['F'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['G'])) {
	   			$jp = $_POST['G'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['H'])) {
	   			$jp = $_POST['H'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['I'])) {
	   			$jp = $_POST['I'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['J'])) {
	   			$jp = $_POST['J'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['K'])) {
	   			$jp = $_POST['K'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['L'])) {
	   			$jp = $_POST['L'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['M'])) {
	   			$jp = $_POST['M'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['N'])) {
	   			$jp = $_POST['N'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['O'])) {
	   			$jp = $_POST['O'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['P'])) {
	   			$jp = $_POST['P'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['Q'])) {
	   			$jp = $_POST['Q'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['R'])) {
	   			$jp = $_POST['R'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['S'])) {
	   			$jp = $_POST['S'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['T'])) {
	   			$jp = $_POST['U'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['U'])) {
	   			$jp = $_POST['U'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['V'])) {
	   			$jp = $_POST['V'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['W'])) {
	   			$jp = $_POST['W'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['X'])) {
	   			$jp = $_POST['X'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['Y'])) {
	   			$jp = $_POST['Y'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}else if (isset($_POST['Z'])) {
	   			$jp = $_POST['Z'];
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE nama_penyakit LIKE '$jp%' ORDER BY nama_penyakit ASC");
	   		}
	   		else{
	   			$detail = mysqli_query($conn, "SELECT * FROM penyakit ORDER BY nama_penyakit ASC");
	   		}

	   		 ?>
	   		 <br>
	   		 <br>
   		</div>

   		<h2>Daftar Penyakit</h2>
		<div class="row pb-5">
			
			<?php while ($data = mysqli_fetch_assoc($detail)) { ?>	
			<div class="col-12 col-md-4 col-sm-12 mt-3">
				<a href="index.php?page=detail_jp&id=<?php echo $data['id_penyakit']; ?>"><?php echo $data['nama_penyakit']; ?></a>
			</div>
			<?php } ?>
		</div>
	</div>

   </div>