<?php 
		include './koneksi.php';
		$detail = mysqli_query($conn, "SELECT * FROM penyakit WHERE id_penyakit = '$_GET[id]'");
		$judul = mysqli_query($conn, "SELECT * FROM penyakit WHERE id_penyakit = '$_GET[id]'");
		$jd = mysqli_fetch_assoc($judul);
 ?>

 <title><?php echo $jd['nama_penyakit']; ?></title>

<div class="detail-content">
	<div class="container">
		<?php while ($data = mysqli_fetch_assoc($detail)) { ?>
		<div class="text-h1">
			<center><?php echo $data['nama_penyakit']; ?></center>
		</div>
		<br>
		<center><img class="card-img-top" style="width: 50%;" src="./assets/images/penyakit/<?php echo $data['gambar']; ?>" alt="Card image cap"></center>
		<br>
		<p><?php echo nl2br(str_replace('', '', htmlspecialchars($data['spesifikasi']))) ?></p>

	<?php } ?>
	</div>
</div>