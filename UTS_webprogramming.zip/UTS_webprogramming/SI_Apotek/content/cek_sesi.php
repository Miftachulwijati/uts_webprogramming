<?php 
session_start();

include '../koneksi.php';

$username = $_POST['username'];
$email = $_POST['email'];
$password = sha1($_POST['password']);

$login = mysqli_query($conn,"select * from user where email = '$username' or username='$username' and password='$password'");

$cek = mysqli_num_rows($login);

if($cek > 0){
 
	$data = mysqli_fetch_assoc($login);

		$_SESSION["id"] = $data["id_user"];
		$_SESSION["nama"] = $data["nama_user"];
        $_SESSION["username"] = $data["username"];
        $_SESSION["email"] = $data["email"];
        $_SESSION["level"] = $data["level"];

        if($_SESSION["level"] == 'admin') {
            header("location:../admin/index.php");
        }else if($_SESSION["level"] == 'pegawai') {
            header("location:../admin/index.php");
        }else{
		header("location:../content/login.php?pesan=gagal");
	}	
}else{
	header("location:../content/login.php?pesan=gagal");
}
 
?>
