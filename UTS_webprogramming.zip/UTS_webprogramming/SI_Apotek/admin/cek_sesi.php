<?php 
if (isset($_SESSION["level"])) {
	if($_SESSION["level"] != 'admin'){
		require '../content/login.php';
		exit();	
	}
}elseif(!isset($_SESSION["level"])) {
	require '../content/login.php';
		exit();
}

 ?>