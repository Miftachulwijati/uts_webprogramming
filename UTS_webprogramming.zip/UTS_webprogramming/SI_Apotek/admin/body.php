<body>
    <div id="wrapper">
      <?php
        require 'models/navbar.php';
      ?>
      <div id="page-wrapper">
        <?php 
          if(@$_GET['page']=='Dashboard' || @$_GET['page']==''){
            include "views/dash.php";
          
          }elseif (@$_GET['page']=='jp') {
            include "views/jenis_penyakit.php";
          }elseif (@$_GET['page']=='tambah_jp') {
            include "views/crud/tambah_jp.php";
          }elseif (@$_GET['page']=='edit_jp') {
            include "views/crud/edit_jp.php";
          }elseif (@$_GET['page']=='hapus_jp') {
            include "views/crud/hapus_jp.php";

          }elseif (@$_GET['page']=='obat') {
            include "views/obat.php";
          }elseif (@$_GET['page']=='tambah_obat') {
            include "views/crud/tambah_obat.php";
          }elseif (@$_GET['page']=='edit_obat') {
            include "views/crud/edit_obat.php";
          }elseif (@$_GET['page']=='hapus_obat') {
            include "views/crud/hapus_obat.php";

          
         
          }elseif (@$_GET['page']=='User') {
            include "views/dt_user.php";
          }elseif (@$_GET['page']=='tambah_usr') {
            include "views/crud/tambah_usr.php";
          }elseif (@$_GET['page']=='edit_user') {
            include "views/crud/edit_usr.php";
          }elseif (@$_GET['page']=='hps_user') {
            include "views/crud/hapus_user.php";
         

          }elseif (@$_GET['page']=='edit_gmbr') {
            include "views/crud/edit_gmbr.php";

          }elseif (@$_GET['page']=='tambah_slide') {
            include "views/crud/tambah_slide.php";
          }elseif (@$_GET['page']=='edit_slide') {
            include "views/crud/edit_slide.php";
          }elseif (@$_GET['page']=='hps_slide') {
            include "views/crud/hapus_slide.php";
          
          }elseif (@$_GET['page']=='adminprof') {
            include "views/admin_prof.php";
          }elseif (@$_GET['page']=='cont_us') {
            include "views/cont_us.php";
          }elseif (@$_GET['page']=='Profil') {
            include "views/profil.php";
            }elseif (@$_GET['page']=='edit_about') {
            include "views/crud/edit_about.php";
          
          }elseif (@$_GET['page']=='ubah_nama') {
            include "views/crud/edit_nama.php";
          }elseif (@$_GET['page']=='ubah_username') {
            include "views/crud/edit_username.php";
          }elseif (@$_GET['page']=='ubah_email') {
            include "views/crud/edit_email.php";
          }elseif (@$_GET['page']=='ubah_telp') {
            include "views/crud/edit_telp.php";
          }elseif (@$_GET['page']=='ubah_pass') {
            include "views/crud/edit_pass.php";
          }
         
         ?>
      </div>
    </div>
    <script src="include/js/jquery-1.10.2.js"></script>
    <script src="include/js/bootstrap.js"></script> 
    <script type="text/javascript" src="include/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="include/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript" src="include/js/dataTables.responsive.min.js"></script>
    <script type="text/javascript" src="include/js/responsive.bootstrap4.min.js"></script>
    <script type="text/javascript" src="include/js/script.js"></script>

</body>