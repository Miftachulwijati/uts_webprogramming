      <?php 
      include '../koneksi.php';
     
      $admin = "SELECT * FROM user WHERE level ='admin'";

      $sql1 = mysqli_query($conn,$admin);
      $data1 = mysqli_fetch_assoc($sql1);
      ?>
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="navbar-header">
          <a style="color: white;" class="navbar-brand">ADMIN</a>
        </div>
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav side-nav">
            <li><a style="color: white;" href="?page=Dashboard"><i class="text fa-2x fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a style="color: white;" href="?page=Profil"><i class="fa-2x fas fa-user-circle"></i> Profil ApotekMAT</a></li>
            <li><a style="color: white;" href="?page=cont_us"><i class="fa-2x fas fa-address-card"></i> Contact US</a></li>
            <li><a style="color: white;" href="?page=jp"><i class="fa-2x fas fa-heartbeat"></i> Jenis Penyakit</a></li>
            <li><a style="color: white;" href="?page=obat"><i class="fa-2x fas fa-pills"></i> Jenis Obat</a></li>
            <li class="dropdown">
              <a style="color: white;" href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa-2x fas fa-balance-scale"></i> Data Transaksi <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a style="color: white;" href="?page=Transaksi"> Tambah Pemesanan</a></li>
                <li><a style="color: white;" href="?page=Laporan"> Laporan Pemesanan</a></li>
               <!--  <li><a style="color: white;" href="?page=Laporanlaba"> Laporan Laba/Rugi</a></li> -->
              </ul>
            </li>
            <li class="dropdown">
              <a style="color: white;" href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa-2x fas fa-database"></i> Master data <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a style="color: white;" href="?page=User">Data User</a></li>
              </ul>
            </li>
          </ul>

          <ul class="nav navbar-nav navbar-right navbar-user">
            <li class="dropdown user-dropdown">
              <a style="color: white;" href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $data1['username']; ?> <b class="caret"></b></a>
              <ul class="dropdown-menu" style="background: url('img/aqua-d9b59c89.png');">
                 <li><a href="../index.php"><i class="fas fa-home"></i>Home</a></li>
                <li><a href="?page=adminprof"><i class="fa fa-user"></i> Profile</a></li>
                <li class="divider"></li>
                <li><a href="../content/logout.php"><i class="fa fa-power-off"></i> Log Out</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </nav>
