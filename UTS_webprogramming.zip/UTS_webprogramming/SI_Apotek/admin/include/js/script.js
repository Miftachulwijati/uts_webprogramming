$(document).ready(function(){
$('#dtHorizontalVerticalScrollExample').DataTable({
	"scrollX":true,
	"scrollY":"500px",
	"scrollCollapse":true,
});
$('dataTables_length').addClass('bs-select');
});

btn.onclick = function(){
	console.log('yes','no')
}

function limit_words($string, $word_limit){
    $words = explode(" ",$string);
    return implode(" ",array_splice($words,0,$word_limit));
}