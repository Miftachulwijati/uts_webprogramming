	<?php 
	include '../koneksi.php';
	$ambil = "SELECT * FROM contact";
	$sql = mysqli_query($conn,$ambil);
	$data = mysqli_fetch_assoc($sql);
	?>
<div class="row">
	 <div class="col-lg-12">
	 	<h1><i class="fas fa-address-card"></i>	Contact US
	 		<small>Admin</small></h1>
	 		<ol class="breadcrumb">
	 			<li><a href="?page=Dashboard"><i class="fa fa-dashboard"></i>	Dashboard</a>
                </li>
                <li class="active"><i class="fa fa-edit"></i> Contact Us</li>
	 		</ol>
	 </div>
  </div>

  <form method="post" enctype="multipart/form-data">
  	<div class="row">
	  	<div class="col-md-6">
		  <div class="form-group">
		    <label for="formGroupExampleInput">Link Facebook</label>
		    <input type="text" class="form-control" id="formGroupExampleInput" name="Facebook" value="<?php echo $data['facebook']; ?>" required="">
		  </div>
		</div>
		<div class="col-md-6">
		  <div class="form-group">
		    <label for="formGroupExampleInput">WhatsApp</label>
		    <input type="text" class="form-control" id="formGroupExampleInput" name="Whatsapp" value="<?php echo substr_replace($data['whatsapp'], '0', 0,2); ?>"required="">
		  </div>
		</div>
		<div class="col-md-6">
		  <div class="form-group">
		    <label for="formGroupExampleInput">Link Instagram</label>
		    <input type="text" class="form-control" id="formGroupExampleInput" name="Instagram" value="<?php echo $data['instagram']; ?>" required="">
		  </div>
		</div>
		<div class="col-md-6">
			<div class="form-group">
	    		<label for="formGroupExampleInput">Email</label>
	    		<input type="text" class="form-control" id="formGroupExampleInput" name="Email" value="<?php echo $data['email']; ?>"required="">
	  		</div>
  		</div>
	</div>
  
  <div class="form-group">
    <label for="exampleFormControlTextarea1">Location</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="Location"><?php echo $data['location']; ?>"</textarea>
  </div>
  <div class="form-group">
     <label for="exampleFormControlTextarea1">Link Location</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="Link-LOC"><?php echo $data['link_location']; ?>"</textarea>
  </div>
  <button type="submit" class="btn btn-primary" name="Update"><i class="fas fa-edit"></i> Update</button>
  </form>
		<?php 
    		If(isset($_POST['Update'])){
    		$fc = $_POST['Facebook'];
    		$wa = substr_replace($_POST['Whatsapp'], '62', 0,1);
    		$ins = $_POST['Instagram'];
    		$em = $_POST['Email'];
    		$loc = $_POST['Location'];
    		$ll = $_POST['Link-LOC'];
    		$query = "UPDATE contact SET facebook = '$fc', whatsapp = '$wa',
    				  instagram = '$ins', email = '$em', location = '$loc', link_location = '$ll'";
    		$save = mysqli_query($conn, $query);
    		if($save){
    			echo "<script>alert('Data berhasil diubah');</script>";
    			echo "<script>var timer = setTimeout(function()
    			{ window.location= '?page=cont_us'}, 500)</script>";
    		}else{
    			echo "<script>alert('Data gagal disimpan');</script>";
    		}
    	}
	     ?>