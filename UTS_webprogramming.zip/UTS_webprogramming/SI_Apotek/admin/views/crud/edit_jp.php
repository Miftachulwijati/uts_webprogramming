	<?php 
	include '../koneksi.php';
	// $id = isset($_GET['id']) ? $_GET['id'] : '';
	// $ambil = mysqli_query($conn,"SELECT * FROM user WHERE id_user= $id");
	$jenis_penyakit = mysqli_query($conn, "SELECT * FROM penyakit WHERE id_penyakit = '$_GET[id]'");
	$data = mysqli_fetch_assoc($jenis_penyakit);

 ?>
 <div class="row">
    <div class="col-lg-12">
	   <h1 class="page-header"><i class="fa fa-book"></i>
			Form Edit
	   </h1>
       <ol class="breadcrumb">
       </ol>
        <form  method="post" enctype="multipart/form-data" action="">
		<div class="form-group">
		    <label for="formGroupExampleInput">ID Penyakit</label>
		    <input type="text" class="form-control" id="formGroupExampleInput" name="id_penyakit" value="<?php echo $data['id_penyakit']; ?>" readonly>
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput2">Code Penyakit</label>
		    <input type="text" class="form-control" id="formGroupExampleInput2" name="code_penyakit" value="<?php echo $data['code_penyakit']; ?>" required>
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput2">Nama Penyakit</label>
		    <input type="text" class="form-control" id="formGroupExampleInput2" name="nama_penyakit" value="<?php echo $data['nama_penyakit']; ?>">
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput2">Isi Content</label>
		    <textarea type="text" class="form-control" id="formGroupExampleInput2" name="spesifikasi" rows="50" required><?php echo $data['spesifikasi']; ?></textarea>
		</div>
		  <div class="form-group">
		    <label for="formGroupExampleInput">Jenis Penyakit</label>
		    <input type="text" class="form-control" id="formGroupExampleInput" name="jp" value="<?php echo $data['jenis_penyakit']; ?>" required>
		  </div>
  		  <div class="form-group">
		    <label for="formGroupExampleInput">Gambar</label><br>
		    <img src="../assets/images/penyakit/<?php echo $data['gambar'] ?>" width="80px" id="pict" style="margin-bottom: 10px;">
		    <input type="file" class="form-control" id="formGroupExampleInput" name="gambar">
		  </div>
		  
	</div>
		  <button style="margin-left: 15px" type="submit" class="btn btn-success" name="simpan"><i class="fas fa-edit"></i> Update</button>
		</form>
		<?php 
	        		If(isset($_POST['simpan'])){
	        		$id_penyakit= $_POST['id_penyakit'];
	        		$code_penyakit = $_POST['code_penyakit'];
	        		$nama_penyakit = $_POST['nama_penyakit'];
	        		$spesifikasi = trim($_POST['spesifikasi']);
	        		$jenis_penyakit = $_POST['jp'];
	        		$gambar = $_FILES['gambar']['name'];
	        		$temp = $_FILES['gambar']['tmp_name'];
	        		move_uploaded_file($temp,"../assets/images/penyakit/$gambar");
	        		$query = "UPDATE penyakit SET id_penyakit = '$id_penyakit', code_penyakit = '$code_penyakit', nama_penyakit = '$nama_penyakit', spesifikasi = '$spesifikasi', jenis_penyakit = '$jenis_penyakit', gambar = '$gambar' WHERE id_penyakit = '$_GET[id]'";
	        		if(empty($gambar)){
	        			$query = "UPDATE penyakit SET id_penyakit = '$id_penyakit', code_penyakit = '$code_penyakit', nama_penyakit = '$nama_penyakit', spesifikasi = '$spesifikasi', jenis_penyakit = '$jenis_penyakit' WHERE id_penyakit = '$_GET[id]'";
	        		}
	        		$save = mysqli_query($conn, $query);
	        		if($save){
	        			echo "<script>alert('Data berhasil diubah');</script>";
	        			echo "<script>var timer = setTimeout(function()
	        			{ window.location= '?page=jp'}, 500)</script>";
	        		}else{
	        			echo "<script>alert('Data gagal disimpan');</script>";
	        		}
	        	}
	     ?>
    </div>
 </div>