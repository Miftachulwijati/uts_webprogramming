<?php 
require '../koneksi.php';
$b=mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM tb_slide where id_slide='$_GET[id]'"));
$query = "DELETE FROM tb_slide WHERE id_slide='$_GET[id]'";
$hapus = mysqli_query($conn, @$query);
@unlink("../assets/images/sliders/".$b['slide']);

if($hapus){
	echo "<script>alert
			('Data berhasil dihapus');</script>";
			echo "<script>var timer = setTimeout(function()
                        { window.location= '?page=Profil'}, 500)</script>";
			}else{
				echo "<script>alert('Data gagal dihapus');</script>";
			}
	   
 ?>