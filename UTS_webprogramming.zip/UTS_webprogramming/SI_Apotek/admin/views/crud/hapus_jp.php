<?php 
require '../koneksi.php';
$query = "DELETE FROM penyakit WHERE id_penyakit='$_GET[id]'";
$hapus = mysqli_query($conn, $query);

if($hapus){
	echo "<script>alert
		('Data berhasil dihapus');</script>";
	echo "<script>var timer = setTimeout(function()
		{ window.location= '?page=jp'}, 500)</script>";
}else{
	echo "<script>alert('Data gagal dihapus');</script>";
	echo "<script>var timer = setTimeout(function()
		{ window.location= '?page=jp'}, 500)</script>";
}
	
 ?>