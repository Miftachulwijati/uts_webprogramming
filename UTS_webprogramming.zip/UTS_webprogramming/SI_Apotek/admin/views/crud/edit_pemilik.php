	<?php 
	include '../koneksi.php';
	// $id = isset($_GET['id']) ? $_GET['id'] : '';
	// $ambil = mysqli_query($conn,"SELECT * FROM user WHERE id_user= $id");
	$ambil = "SELECT * FROM data_konsumen WHERE id = '$_GET[id]'";
	$sql = mysqli_query($conn,$ambil);
	$data = mysqli_fetch_assoc($sql);

 ?>
 <div class="row">
    <div class="col-lg-12">
	   <h1 class="page-header"><i class="fa fa-book"></i>
			Form Edit
	   </h1>
       <ol class="breadcrumb">
       </ol>
        <form  method="post" enctype="multipart/form-data" action="">
		<div class="form-group">
		    <label for="formGroupExampleInput">Nama Pemilik</label>
		    <input type="text" class="form-control" id="formGroupExampleInput" name="pemilik" value="<?php echo $data['nama']; ?>" required>
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput2">Alamat Domisili</label>
		    <input type="text" class="form-control" id="formGroupExampleInput2" name="domisili" value="<?php echo $data['alama_domisili']; ?>" required>
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput">Alamat KTP</label>
		    <input type="text" class="form-control" id="formGroupExampleInput" name="ktp" value="<?php echo $data['alamat_ktp']; ?>" required>
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput2">No. Telp</label>
		    <input type="text" class="form-control" id="formGroupExampleInput2" name="telp" value="<?php echo $data['no_telp']; ?>" required>
		  </div>
  		  <div class="form-group">
		    <label for="formGroupExampleInput">No. Whatsapp</label>
		    <input type="TEXT" class="form-control" id="formGroupExampleInput" name="whatsapp" value="<?php echo $data['no_wa']; ?>" required>
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput">Email</label>
		    <input type="TEXT" class="form-control" id="formGroupExampleInput" name="email" value="<?php echo $data['email']; ?>" required>
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput2">File 1</label>
		    <img src="../assets/images/pemilik/<?php echo $data['file1'] ?>" width="80px" id="pict" style="margin-bottom: 10px;">
		    <input type="file" name="file1" value="<?php echo $data['file1']; ?>" required>
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput2">File 2</label>
		    <img src="../assets/images/pemilik/<?php echo $data['file2'] ?>" width="80px" id="pict" style="margin-bottom: 10px;">
		    <input type="file" name="file2" value="<?php echo $data['file2']; ?>" required>
		  </div> 
	</div>
		  <button style="margin-left: 15px" type="submit" class="btn btn-success" name="simpan"><i class="fas fa-edit"></i> Update</button>
		</form>
		<?php 
	        		If(isset($_POST['simpan'])){
	        		$pemilik = $_POST['pemilik'];
	        		$domisili = $_POST['domisili'];
	        		$ktp = $_POST['ktp'];
	        		$telp = $_POST['telp'];
	        		$whatsapp = $_POST['whatsapp'];
	        		$email = $_POST['email'];
	        		$file1 = $_FILES['file1']['name'];
	        		$file1temp = $_FILES['file1']['tmp_name'];
	        		$file2 = $_FILES['file2']['name'];
	        		$file2temp = $_FILES['file2']['tmp_name'];
	        		@unlink("../assets/images/pemilik/".$data['file1']);
	        		@unlink("../assets/images/pemilik/".$data['file2']);
	        		move_uploaded_file($file1temp,"../assets/images/pemilik/$file1");
	        		move_uploaded_file($file2temp,"../assets/images/pemilik/$file2");
	        		$query = "UPDATE data_konsumen SET nama = '$pemilik', alama_domisili = '$domisili', alamat_ktp= '$ktp', no_telp = '$telp', no_wa = '$whatsapp', email = '$email', file1 = '$file1', file2 = '$file2' WHERE id = '$_GET[id]'";
	        		$save = mysqli_query($conn, $query);
	        		if($save){
	        			echo "<script>alert('Data berhasil diubah');</script>";
	        			echo "<script>var timer = setTimeout(function()
	        			{ window.location= '?page=Konsumen'}, 500)</script>";
	        		}else{
	        			echo "<script>alert('Data gagal disimpan');</script>";
	        		}
	        	}
	     ?>
    </div>
 </div>