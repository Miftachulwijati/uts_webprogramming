<?php 
	include '../koneksi.php'	;

 ?>
 <div class="row">
    <div class="col-lg-12">
	   <h1 class="page-header"><i class="fa fa-book"></i>
			Form Tambah
	   </h1>
       <ol class="breadcrumb">
       </ol>
<form method="post" enctype="multipart/form-data" action="">
  <div class="form-group">
    <label for="exampleFormControlFile1">Slide</label>
    <input type="file" class="form-control-file" id="exampleFormControlFile1" multiple name="gambar[]">
  </div>

  <div class="form-group">
        <label for="formGroupExampleInput">Title</label>
        <input type="text" class="form-control" id="formGroupExampleInput" name="Title" autocomplete="off" required>
  </div>
      <div class="form-group">
        <label for="formGroupExampleInput2">Text</label>
        <input type="text" class="form-control" id="formGroupExampleInput2" name="Text" autocomplete="off" required>
      </div>

 <button type="submit" class="btn btn-success" name="simpan">Simpan</button>
    </form>
          <?php 
          $Title = @$_POST['Title'];
            if (isset($_POST["simpan"])) {
        $jumlah = count($_FILES['gambar']['name']);
        if ($jumlah > 0) {
         for ($i=0; $i < $jumlah; $i++) { 
        $file_name = $_FILES['gambar']['name'][$i];
        $tmp_name = $_FILES['gambar']['tmp_name'][$i];        
        move_uploaded_file($tmp_name, "../assets/images/sliders/".$file_name);
        mysqli_query($conn,"INSERT INTO tb_slide VALUES(NULL,'$Title',
          '".$_POST['Text']."',
                '$file_name')");       
      }
      echo "<script>alert('Data berhasil disimpan');</script>";
                echo "<script>var timer = setTimeout(function()
                { window.location= '?page=Profil'}, 500)</script>";
    }else{
       echo "<script>alert('Data gagal disimpan');</script>";
    }
  }
           ?>
         </div>
       </div>