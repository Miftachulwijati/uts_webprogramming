	<?php 
	include '../koneksi.php';
	$obat = mysqli_query($conn, "SELECT * FROM Obat WHERE id_obat = '$_GET[id]'");
	$data = mysqli_fetch_assoc($obat);

 ?>
 <div class="row">
    <div class="col-lg-12">
	   <h1 class="page-header"><i class="fa fa-book"></i>
			Form Edit
	   </h1>
       <ol class="breadcrumb">
       </ol>
        <form  method="post" enctype="multipart/form-data" action="">
		<div class="form-group">
		    <label for="formGroupExampleInput">ID Obat</label>
		    <input type="text" class="form-control" id="formGroupExampleInput" name="id_obat" value="<?php echo $data['id_obat']; ?>" readonly>
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput2">Code Obat</label>
		    <input type="text" class="form-control" id="formGroupExampleInput2" name="code_obat" value="<?php echo $data['code_obat']; ?>" required>
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput2">Barcode</label>
		    <input type="text" class="form-control" id="formGroupExampleInput2" name="barcode" value="<?php echo $data['barcode']; ?>" required>
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput2">Nama Obat</label>
		    <input type="text" class="form-control" id="formGroupExampleInput2" name="nama_obat" value="<?php echo $data['nama_obat']; ?>">
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput2">Jenis Obat</label>
		    <input type="text" class="form-control" id="formGroupExampleInput2" name="jenis_obat" value="<?php echo $data['jenis_obat']; ?>" required>
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput2">Isi Content</label>
		    <textarea type="text" class="form-control" id="formGroupExampleInput2" name="spesifikasi" rows="20" required><?php echo $data['spesifikasi']; ?></textarea>
		</div>
		  <div class="form-group">
		    <label for="formGroupExampleInput">Harga Beli</label>
		    <input type="text" class="form-control" id="formGroupExampleInput" name="harga_beli" value="<?php echo $data['harga_beli']; ?>" required>
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput">Harga Jual</label>
		    <input type="text" class="form-control" id="formGroupExampleInput" name="harga_jual" value="<?php echo $data['harga_jual']; ?>" required>
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput">Satuan</label>
		    <input type="text" class="form-control" id="formGroupExampleInput" name="satuan" value="<?php echo $data['satuan']; ?>" required>
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput">Stok</label>
		    <input type="text" class="form-control" id="formGroupExampleInput" name="stok" value="<?php echo $data['stok']; ?>" required>
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput">Tanggal Expired</label>
		    <input type="date" class="form-control" id="formGroupExampleInput" name="tgl" value="<?php echo $data['tgl_expired']; ?>" required>
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput">Supplier</label>
		    <input type="text" class="form-control" id="formGroupExampleInput" name="supplier" value="<?php echo $data['supplier']; ?>" required>
		  </div>
  		  <div class="form-group">
		    <label for="formGroupExampleInput">Gambar</label><br>
		    <img src="../assets/images/obat/<?php echo $data['gambar'] ?>" width="80px" id="pict" style="margin-bottom: 10px;">
		    <input type="file" class="form-control" id="formGroupExampleInput" name="gambar">
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput">Indikasi</label>
		    <input type="text" class="form-control" id="formGroupExampleInput" name="indikasi" value="<?php echo $data['indikasi']; ?>" required>
		  </div>
		  
	</div>
		  <button style="margin-left: 15px" type="submit" class="btn btn-success" name="simpan"><i class="fas fa-edit"></i> Update</button>
		</form>
		<?php 
	        		If(isset($_POST['simpan'])){
	        		$id_obat= $_POST['id_obat'];
	        		$code_obat = $_POST['code_obat'];
	        		$barcode = $_POST['barcode'];
	        		$nama_obat = $_POST['nama_obat'];
	        		$jenis_obat = $_POST['jenis_obat'];
	        		$spesifikasi = trim($_POST['spesifikasi']);
	        		$harga_beli = $_POST['harga_beli'];
	        		$harga_jual = $_POST['harga_jual'];
	        		$satuan = $_POST['satuan'];
	        		$stok = $_POST['stok'];
	        		$tgl = $_POST['tgl'];
	        		$supplier = $_POST['supplier'];
	        		$gambar = $_FILES['gambar']['name'];
	        		$temp = $_FILES['gambar']['tmp_name'];
	        		move_uploaded_file($temp,"../assets/images/obat/$gambar");
	        		$indikasi = $_POST['indikasi'];	        		

	        			$query = "UPDATE obat SET id_obat = '$id_obat', code_obat = '$code_obat', barcode = '$barcode', nama_obat = '$nama_obat', jenis_obat = '$jenis_obat', spesifikasi = '$spesifikasi', harga_beli = '$harga_beli', harga_jual = '$harga_jual', satuan = '$satuan', stok = '$stok', tgl_expired = '$tgl', supplier = '$supplier', gambar = '$gambar', indikasi = '$indikasi' WHERE id_obat = '$_GET[id]'";
	        		if(empty($gambar)){
	        			$query = "UPDATE obat SET id_obat = '$id_obat', code_obat = '$code_obat', barcode = '$barcode', nama_obat = '$nama_obat', jenis_obat = '$jenis_obat', spesifikasi = '$spesifikasi', harga_beli = '$harga_beli', harga_jual = '$harga_jual', satuan = '$satuan', stok = '$stok', tgl_expired = '$tgl', supplier = '$supplier', indikasi = '$indikasi' WHERE id_obat = '$_GET[id]'";
	        		}
	        		$save = mysqli_query($conn, $query);
	        		if($save){
	        			echo "<script>alert('Data berhasil diubah');</script>";
	        			echo "<script>var timer = setTimeout(function()
	        			{ window.location= '?page=obat'}, 500)</script>";
	        		}else{
	        			echo "<script>alert('Data gagal disimpan');</script>";
	        		}
	        	}
	     ?>
    </div>
 </div>