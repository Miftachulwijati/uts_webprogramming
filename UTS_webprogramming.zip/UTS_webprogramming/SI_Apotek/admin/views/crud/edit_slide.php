	<?php 
	include '../koneksi.php';
	// $id = isset($_GET['id']) ? $_GET['id'] : '';
	// $ambil = mysqli_query($conn,"SELECT * FROM user WHERE id_user= $id");
	$ambil = "SELECT * FROM tb_slide WHERE id_slide = '$_GET[id]'";
	$sql = mysqli_query($conn,$ambil);
	$data = mysqli_fetch_assoc($sql);

 ?>
 <div class="contaainer-fluid">
 <div class="row">
    <div class="col-lg-12">
	   <h1 class="page-header"><i class="fa fa-book"></i>
			Form Edit
	   </h1>
       <ol class="breadcrumb">
       </ol>
        <form  method="post" enctype="multipart/form-data" action="">
		  <div class="form-group">
            <label for="formGroupExampleInput">Title</label>
                <input type="text" class="form-control" id="formGroupExampleInput" name="title" value="<?php echo $data['title']; ?>" required>
                <br>
            <label for="formGroupExampleInput">Text</label>
                <input type="text" class="form-control" id="formGroupExampleInput" name="text" value="<?php echo $data['textslide']; ?>" required>
                <br>
		    <label for="exampleFormControlFile1">Slide Gambar</label>
		    <div style="padding-bottom">
                
		    	<img src="../assets/images/sliders/<?php echo $data['slide'] ?>" width="80px" id="pict" style="margin-bottom: 10px;">
		    
		    <input type="file" class="form-control-file" id="exampleFormControlFile1" name="file-1" value="<? echo $data['logo'];?>">
            </div>
		  </div>
  		  
	</div>
		  <button type="submit" class="btn btn-success" style="margin-left: 16px;" name="simpan">Simpan</button>
          <a href="?page=Profil" class="btn btn-warning">Batal</a>
		</form>
		<?php
    If(isset($_POST['simpan'])){
        $title = $_POST['title'];
        $text = $_POST['text'];

        if(isset($_FILES['file-1'])&&($_FILES['file-1'])){
        $name    =$_FILES['file-1']['name'];
        $temp    =$_FILES['file-1']['tmp_name'];
        $size    =$_FILES['file-1']['size'];
        move_uploaded_file($temp, "../assets/images/sliders/$name");
    }
    if(empty($name)){
    $update = "UPDATE tb_slide set title = '$title', textslide = '$text' where id_slide = '$_GET[id]'";
    }else{
        // @unlink("../assets/images/sliders/".$data['slide']);
        $update = "UPDATE tb_slide set title = '$title', textslide = '$text' ,slide ='$name' where id_slide = '$_GET[id]'";
    }

    $save = mysqli_query($conn, $update);
    if($save){
        echo "<script>alert('Berhasil Di Ubah')</script>";
        echo "<script>var timer = setTimeout(function()
                        { window.location= '?page=Profil'}, 500)</script>";
    }else{
        echo "<script>alert('gagal)</script>";
    }
      }        
    ?>
    </div>
 </div>
 </div>