<?php 
	include '../koneksi.php';

	$code = mysqli_query($conn, "SELECT * FROM obat WHERE id_obat IN(SELECT MAX(id_obat) FROM obat)");
	$cd = mysqli_fetch_assoc($code);
	$char = "JB";
	$hasil = $char.sprintf("%04s",$cd['id_obat']+1);

 ?>

 <div class="row">
    <div class="col-lg-12">
	   	<h1 class="page-header"><i class="fa fa-book"></i>
			Form Tambah Data
	   	</h1>
       	<ol class="breadcrumb"></ol>
        <form  method="post" enctype="multipart/form-data" action="">
		  	<div class="form-group" hidden>
			    <label for="formGroupExampleInput2">ID Obat</label>
			    <input type="text" class="form-control" id="formGroupExampleInput2" name="id_obat" value="<?php echo $cd['id_obat']+1 ?>" required>
		  	</div>
		  	<div class="form-group">
			    <label for="formGroupExampleInput2">Code Obat</label>
			    <input type="text" class="form-control" id="formGroupExampleInput2" name="code_obat" value="<?php echo $hasil ?>" required>
		  	</div>
		  	<div class="form-group">
			    <label for="formGroupExampleInput2">Barcode</label>
			    <input type="text" class="form-control" id="formGroupExampleInput2" name="barcode" required>
		  	</div>
		  	<div class="form-group">
			    <label for="formGroupExampleInput2">Nama Obat</label>
			    <input type="text" class="form-control" id="formGroupExampleInput2" name="nama_obat" required>
		  	</div>
		  	<div class="form-group">
			    <label for="formGroupExampleInput2">Jenis Obat</label>
			    <input type="text" class="form-control" id="formGroupExampleInput2" name="jenis_obat" required>
		  	</div>
		  	<div class="form-group">
			    <label for="formGroupExampleInput2">Isi Content</label>
			    <textarea type="text" class="form-control" id="formGroupExampleInput2" name="spesifikasi" rows="50" required></textarea>
			</div>
			<div class="form-group">
			    <label for="formGroupExampleInput2">Harga Beli</label>
			    <input type="text" class="form-control" id="formGroupExampleInput2" name="harga_beli" required>
		  	</div>
		  	<div class="form-group">
			    <label for="formGroupExampleInput2">Harga Jual</label>
			    <input type="text" class="form-control" id="formGroupExampleInput2" name="harga_jual" required>
		  	</div>
		  	<div class="form-group">
			    <label for="formGroupExampleInput2">Satuan</label>
			    <input type="text" class="form-control" id="formGroupExampleInput2" name="satuan" required>
		  	</div>
		  	<div class="form-group">
			    <label for="formGroupExampleInput2">Stok</label>
			    <input type="text" class="form-control" id="formGroupExampleInput2" name="stok" required>
		  	</div>
		  	<div class="form-group">
			    <label for="formGroupExampleInput2">Tanggal Expired</label>
			    <input type="date" class="form-control" id="formGroupExampleInput2" name="tgl" required>
		  	</div>
		  	<div class="form-group">
			    <label for="formGroupExampleInput2">Supplier</label>
			    <input type="text" class="form-control" id="formGroupExampleInput2" name="supplier" required>
		  	</div>
  		  	<div class="form-group">
			    <label for="formGroupExampleInput">Gambar</label><br>
			    <input type="file" class="form-control" id="formGroupExampleInput" name="gambar" required>
		  	</div>
		  	<div class="form-group">
			    <label for="formGroupExampleInput2">Indikasi</label>
			    <input type="text" class="form-control" id="formGroupExampleInput2" name="indikasi" required>
		  	</div>
		  
			<div>
		  		<button style="margin-left: 15px" type="submit" class="btn btn-success" name="simpan"><i class="fas fa-edit"></i> Update</button>
		  	</div>
		</form>
		<?php 
	        If(isset($_POST['simpan'])){
	        	$id_obat = $_POST['id_obat'];
	        	$code_obat = $_POST['code_obat'];
	        	$barcode = $_POST['barcode'];
	        	$nama_obat = $_POST['nama_obat'];
	        	$jenis_obat = $_POST['jenis_obat'];
	        	$spesifikasi = trim($_POST['spesifikasi']);
	        	$harga_beli = $_POST['harga_beli'];
	        	$harga_jual = $_POST['harga_jual'];
	        	$satuan = $_POST['satuan'];
	        	$stok = $_POST['stok'];
	        	$tgl = $_POST['tgl'];
	        	$supplier = $_POST['supplier'];
	        	$gambar = $_FILES['gambar']['name'];
	        	$temp = $_FILES['gambar']['tmp_name'];
	        	move_uploaded_file($temp,"../assets/images/obat/$gambar");
	        	$indikasi = $_POST['indikasi'];

	        	$query = "INSERT INTO obat(id_obat, code_obat, barcode, nama_obat, jenis_obat, spesifikasi, harga_beli, harga_jual, satuan, stok, tgl_expired, supplier, gambar, indikasi) VALUES('$id_obat', '$code_obat', '$barcode', '$nama_obat', '$jenis_obat', '$spesifikasi', '$harga_beli', '$harga_jual', '$satuan', '$stok', '$tgl', '$supplier', '$gambar', '$indikasi')";
	   
	        	$save = mysqli_query($conn, $query);
	        	if($save){
	        		echo "<script>alert('Data berhasil diubah');</script>";
	        		echo "<script>var timer = setTimeout(function()
	        		{ window.location= '?page=obat'}, 500)</script>";
	        	}else{
	        		echo "<script>alert('Data gagal disimpan');</script>";
	        	}
	        }
	     ?>
    </div>
 </div>