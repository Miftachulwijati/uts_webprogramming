<?php 
	include '../koneksi.php';
	// $id = isset($_GET['id']) ? $_GET['id'] : '';
	// $ambil = mysqli_query($conn,"SELECT * FROM user WHERE id_user= $id");
	$ambil = "SELECT * FROM data_profilweb WHERE id = '$_GET[id]'";
	$sql = mysqli_query($conn,$ambil);
	$data = mysqli_fetch_assoc($sql);

 ?>
 <div class="contaainer-fluid">
 <div class="row">
    <div class="col-lg-12">
	   <h1 class="page-header"><i class="fa fa-book"></i>
			Form Edit
	   </h1>
       <ol class="breadcrumb">
       </ol>
        <form  method="post" enctype="multipart/form-data" action="">
		  <div class="form-group">
		    <label for="formGroupExampleInput">Profil</label>
		    <textarea type="text" class="form-control" id="formGroupExampleInput" rows="5" name="profil" required><?php echo $data['profil']; ?>
		    </textarea> 
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput2">Visi</label>
		    <textarea type="text" class="form-control" id="formGroupExampleInput2" rows="5" name="visi" required><?php echo $data['visi']; ?>
		    </textarea>
		  </div>
		  <div class="form-group">
		    <label for="formGroupExampleInput2">Misi</label>
		    <textarea type="text" class="form-control" id="formGroupExampleInput2" rows="5" name="misi" required><?php echo $data['misi']; ?>
		    </textarea> 
		  </div>
  		  
	</div>
		  <button type="submit" class="btn btn-success" style="margin-left: 16px;" name="simpan"><i class="fas fa-edit"></i> Update</button>
		</form>
		<?php 
	        		If(isset($_POST['simpan'])){
	        		$profil = trim($_POST['profil']);
	        		$visi = trim($_POST['visi']);
	        		$misi = trim($_POST['misi']);
	        		$query = "UPDATE data_profilweb SET profil = '$profil', visi = '$visi', misi = '$misi' WHERE id = '$_GET[id]'";
	        		$save = mysqli_query($conn, $query);
	        		if($save){
	        			echo "<script>alert('Data berhasil diubah');</script>";
	        			echo "<script>var timer = setTimeout(function()
	        			{ window.location= '?page=Profil'}, 500)</script>";
	        		}else{
	        			echo "<script>alert('Data gagal disimpan');</script>";
	        		}
	        	}
	     ?>
    </div>
 </div>
 </div>