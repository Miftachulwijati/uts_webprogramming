<?php 
	include '../koneksi.php';

	$code = mysqli_query($conn, "SELECT * FROM penyakit WHERE id_penyakit IN(SELECT MAX(id_penyakit) FROM penyakit)");
	$cd = mysqli_fetch_assoc($code);
	$char = "JP";
	$hasil = $char.sprintf("%04s",$cd['id_penyakit']+1);

 ?>

 <div class="row">
    <div class="col-lg-12">
	   	<h1 class="page-header"><i class="fa fa-book"></i>
			Form Tambah Data
	   	</h1>
       	<ol class="breadcrumb"></ol>
        <form  method="post" enctype="multipart/form-data" action="">
		  	<div class="form-group" hidden>
			    <label for="formGroupExampleInput2">ID Penyakit</label>
			    <input type="text" class="form-control" id="formGroupExampleInput2" name="id_penyakit" value="<?php echo $cd['id_penyakit']+1 ?>" required>
		  	</div>
		  	<div class="form-group">
			    <label for="formGroupExampleInput2">Code Penyakit</label>
			    <input type="text" class="form-control" id="formGroupExampleInput2" name="code_penyakit" value="<?php echo $hasil ?>" required>
			</div>
			<div class="form-group">
			    <label for="formGroupExampleInput2">Nama Penyakit</label>
			    <input type="text" class="form-control" id="formGroupExampleInput2" name="nama_penyakit"required>
		  	</div>
		  	<div class="form-group">
			    <label for="formGroupExampleInput2">Isi Content</label>
			    <textarea type="text" class="form-control" id="formGroupExampleInput2" name="spesifikasi" rows="50" required></textarea>
			</div>
		  	<div class="form-group">
			    <label for="formGroupExampleInput">Jenis Penyakit</label>
			    <input type="text" class="form-control" id="formGroupExampleInput" name="jp" required>
		  	</div>
  		  	<div class="form-group">
			    <label for="formGroupExampleInput">Gambar</label><br>
			    <input type="file" class="form-control" id="formGroupExampleInput" name="gambar" required>
		  	</div>
		  	<div>
		  		<button style="margin-left: 15px" type="submit" class="btn btn-success" name="simpan"><i class="fas fa-edit"></i> Update</button>
		  	</div>
		  
		</form>
		<?php 
	        If(isset($_POST['simpan'])){
	        	$id_penyakit = $_POST['id_penyakit'];
	        	$code_penyakit = $_POST['code_penyakit'];
	        	$nama_penyakit = $_POST['nama_penyakit'];
	        	$spesifikasi = trim($_POST['spesifikasi']);
	        	$jenis_penyakit = $_POST['jp'];
	        	$gambar = $_FILES['gambar']['name'];
	        	$temp = $_FILES['gambar']['tmp_name'];
	        	move_uploaded_file($temp,"../assets/images/penyakit/$gambar");
	        	$query = "INSERT INTO penyakit(id_penyakit, code_penyakit, nama_penyakit, spesifikasi, jenis_penyakit, gambar) VALUES('$id_penyakit', $code_penyakit', '$nama_penyakit', '$spesifikasi', '$jenis_penyakit', '$gambar')";
	   
	        	$save = mysqli_query($conn, $query);
	        	if($save){
	        		echo "<script>alert('Data berhasil diubah');</script>";
	        		echo "<script>var timer = setTimeout(function()
	        			{ window.location= '?page=jp'}, 500)</script>";
	        	}else{
	        		echo "<script>alert('Data gagal disimpan');</script>";
	        	}
	        }
	     ?>
    </div>
 </div>