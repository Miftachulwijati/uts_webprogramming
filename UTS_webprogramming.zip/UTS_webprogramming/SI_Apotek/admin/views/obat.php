<?php 

  	include '../koneksi.php'; 
  	$obat = mysqli_query($conn, "SELECT * FROM obat ORDER BY code_obat");

 ?>
<div class="row">
	<div class="col-lg-12">
	 	<h1>Master Data
	 		<small>Data Obat</small></h1>
	 		<ol class="breadcrumb">
	 			<li><a href="?page=Dashboard"><i class="fa fa-dashboard"></i>	Dashboard</a>
                </li>
                <li class="active"><i class="fa fa-edit"></i> Data Obat</li>
	 		</ol>
	</div>
</div>
<a href="?page=tambah_obat"><button type="button" class="btn btn-info"><i class="fas fa-edit"></i>Tambah Data</button></a>
<br>
<br>

    <div class="row">
	  <div class="col-lg-12">
		 	<div class="table-responsive"></div>
		 		<table style="margin-top: 15px;" class="table table-bordered table-striped" id="dtHorizontalVerticalScrollExample" cellspacing="0">
		 			<thead>
			 			<tr>
			 				<th style="width: 5%;">No</th>
			 				<th style="width: 5%;">Code Obat</th>
			 				<th style="width: 10%;">Barcode</th>
			 				<th style="width: 10%;">Nama Obat</th>
			 				<th style="width: 10%;">Jenis Obat</th>
			 				<th style="width: 10%;">Isi Content</th>
			 				<th style="width: 10%;">Harga Beli</th>
			 				<th style="width: 10%;">Harga Jual</th>
			 				<th style="width: 10%;">Satuan</th>
			 				<th style="width: 10%;">Stok</th>
			 				<th style="width: 10%;">Tgl Expired</th>
			 				<th style="width: 10%;">Supplier</th>
			 				<th style="width: 5%;">Gambar</th>
			 				<th style="width: 10%;">Indikasi</th>
			 				<th style="width: 10%">Opsi</th>
			 			</tr>
		 			</thead>	
		 			<tbody>
		 				
		 				 <?php
		 				 	function limit_words($string, $word_limit){
						    $words = explode(" ",$string);
						    return implode(" ",array_splice($words,0,$word_limit));
							}

		 				 	$no = 1;
		 					if(mysqli_num_rows($obat)>0){
		 					while ($data  = mysqli_fetch_array($obat)){
		 					
		 				 ?>
			 			<tr>
			 				<td><center><?php echo $no++; ?>.</center></td>
			 				<td><?php echo $data['code_obat']; ?></td>
			 				<td><?php echo $data['barcode']; ?></td>
			 				<td><?php echo $data['nama_obat'] ?></td>
			 				<td><?php echo $data['jenis_obat']; ?></td>
			 				<td style="overflow: hidden;text-overflow: ellipsis;"><?php echo limit_words($data['spesifikasi'],10); ?></td>
			 				<td><?php echo number_format($data['harga_jual']); ?></td>
			 				<td><?php echo number_format($data['harga_beli']); ?></td>
			 				<td><?php echo $data['satuan']; ?></td>
			 				<td><?php echo $data['stok']; ?></td>
			 				<td><?php echo $data['tgl_expired']; ?></td>
			 				<td><?php echo $data['supplier']; ?></td>
			 				<td>
			 					<img src="../assets/images/obat/<?php echo $data['gambar']; ?>" style="width: 90px; height: 80px;">
			 				</td>
			 				<td><?php echo $data['indikasi']; ?></td>
			 				<td>
			 					<a href="?page=edit_obat&id=<?php echo $data['id_obat']; ?>"><button type="button" class="btn btn-info"><i class="fas fa-edit"></i></button></a>
			 					<a href="?page=hapus_obat&id=<?php echo $data['id_obat']; ?>"><button type="button" class="btn btn-danger"><i class="fas fa-trash-alt"></i></button>
			 				</td>
			 			</tr>
			 			<?php }
			 			}else{
			 				echo "<tr><td colspan=\"10\"align=\"center\">Data Tidak Ditemukan</td></tr>";
			 			}
			 			?>
			 			
			 		</tbody>
		 		</table>
	 	</div>

