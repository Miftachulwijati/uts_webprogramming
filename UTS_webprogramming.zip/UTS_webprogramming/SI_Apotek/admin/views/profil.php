 <?php 

  	include '../koneksi.php';

  	$ambil = mysqli_query($conn,"SELECT * FROM tb_gambar");
  	$slide = mysqli_query($conn,"SELECT * FROM tb_slide");
  	$contact =mysqli_query($conn, "SELECT * FROM  contact");
  	$profil = mysqli_query($conn, "SELECT * FROM data_profilweb");

   ?>
<div class="container-fluids">
<div class="row">
	<div class="col-lg-12">
		<h1> <i class="fa fa-user"></i>
			Profile ApotekMAT
		    <small>Admin</small>
			   </h1>
		<ol class="breadcrumb">
		   <li>
			   <a href="?page=Dashboard"><i class="fa fa-dashboard"></i>	Dashboard</a>
			   <li class="active"><i class="fa fa-user"></i> Profile ApotekMAT</li>
		   </li>
		 </ol>

	</div>
</div>

<h2 class="title" align="center">About ApotekMAT</h2>
<!--   </div> -->
    <div class="row">
	  <div class="col-lg-12">
		 	<div class="table-responsive"></div>
		 	<div class="container-fluids">
		 		<table class="table table-bordered table-striped">
		 			<thead>
			 			<tr>
			 				<th style="width: 2%;">No</th>
			 				<th>Profil</th>
			 				<th>Visi</th>
			 				<th>Misi</th>
			 				<th style="width: 10%;">Opsi</th>
			 			</tr>
		 			</thead>
		 			<tbody>
		 				<?php 
		 					$no= 1;
		 					while ($data = mysqli_fetch_assoc($profil)) {
		 					
		 				 ?>
			 			<tr>
			 				<td><?php echo $no++ ;?>.</td>
			 				<td><?php echo $data['profil']; ?></td>
			 				<td><?php echo $data['visi']; ?></td>
			 				<td><?php echo $data['misi']; ?></td>
			 				<td>
			 					<a href="?page=edit_about&id=<?php echo $data['id']; ?>"><button type="button" class="btn btn-info"><i class="fas fa-edit"></i></button></i></a>

			 				</td>
			 			</tr>
			 			<?php } ?>
			 		</tbody>
		 		</table>
			</div>
		</div>
	</div>


	<h2 class="title" align="center">Logo</h2>
 
<!--   </div> -->
    <div class="row">
	  <div class="col-lg-12">
		 	<div class="table-responsive"></div>
		 	<div class="container-fluids">
		 		<table class="table table-bordered table-striped">
		 			<thead>
			 			<tr>
			 				<th width="2%">No</th>
			 				<th style="width: 85%; align-content: center;">Logo</th>
			 				<th style="width: 9.5%;">Opsi</th>
			 			</tr>
		 			</thead>
		 			<tbody>
		 				<?php 
		 					$i = 1;
		 					while ($data = mysqli_fetch_assoc($ambil)) {
		 					
		 				 ?>
			 			<tr>
			 				<td><?php echo $i++; ?>.</td>
			 				<td>
			 					<img src="../assets/images/<?php echo $data['logo']; ?>" style="width: 90px; height: 80px;"></td>
			 				<td>
			 					<a href="?page=edit_gmbr&id=<?php echo $data['id_logo']; ?>" data><button type="button" class="btn btn-info"><i class="fas fa-edit"></i></button></a>
			 					
			 				</td>
			 			</tr>
			 			<?php } ?>
			 		</tbody>
		 		</table>

	 		</div>
	 	</div>
	 </div>
<h2 class="title" align="center">Slide Gambar</h2>
 
<!--   </div> -->
    <div class="row">
	  <div class="col-lg-12">
		 	<div class="table-responsive"></div>
		 	<div class="container-fluids">
		 		<table class="table table-bordered table-striped">
		 			<thead>
			 			<tr>
			 				<th>No</th>
			 				<th style="width: 10%; align-content: center;">Slide</th>
			 				<th style="width: 40%; align-content: center;">Title</th>
			 				<th style="width: 40%; align-content: center;">Text</th>
			 				<th style="width: 10%;">Opsi</th>
			 			</tr>
		 			</thead>
		 			<tbody>
		 				<?php 
		 					$i = 1;
		 					while ($data = mysqli_fetch_assoc($slide)) {
		 					
		 				 ?>
			 			<tr>
			 				<td><?php echo $i++; ?>.</td>
			 				<td>
			 					<img src="../assets/images/sliders/<?php echo $data['slide']; ?>" style="width: 90px; height: 80px;">
			 				</td>
			 				<td><?php echo $data['title']; ?></td>
			 				<td><?php echo $data['textslide']; ?></td>
			 				<td>
			 					<?php 

			 					if ($data['id_slide'] == 1) {
			 						?>
			 						<a href="?page=edit_slide&id=<?php echo $data['id_slide']; ?>" data><button type="button" class="btn btn-info"><i class="fas fa-edit"></i></button></a>
			 					
			 					<?php 

			 					}else{
			 						?>

			 						<a href="?page=edit_slide&id=<?php echo $data['id_slide']; ?>" data><button type="button" class="btn btn-info"><i class="fas fa-edit"></i></button></a>
			 						<a href="?page=hps_slide&id=<?php echo $data['id_slide']; ?>"><button type="button" class="btn btn-danger" name="Hapus"><i class="fas fa-trash-alt"></i>
			 						</button></a>
			 					<?php  } ?>
			 					

			 				</td>
			 			</tr>
			 			<?php } ?>
			 		</tbody>
		 		</table>

	 		</div>
	 	</div>
	 </div>
	<a href="?page=tambah_slide"><button type="submit" class="btn btn-success"><i class="fas fa-plus"></i> Tambah Data</button></a>

</div>