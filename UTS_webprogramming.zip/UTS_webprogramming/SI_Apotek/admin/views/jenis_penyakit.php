<?php 

  	include '../koneksi.php'; 
  	$jenis_penyakit = mysqli_query($conn, "SELECT * FROM penyakit ORDER BY code_penyakit");

 ?>
<div class="row">
	<div class="col-lg-12">
	 	<h1>Master Data
	 		<small>Data Jenis Penyakit</small></h1>
	 		<ol class="breadcrumb">
	 			<li><a href="?page=Dashboard"><i class="fa fa-dashboard"></i>	Dashboard</a>
                </li>
                <li class="active"><i class="fa fa-edit"></i> Data Jenis Penyakit</li>
	 		</ol>
	</div>
</div>
<a href="?page=tambah_jp"><button type="button" class="btn btn-info"><i class="fas fa-edit"></i>Tambah Data</button></a>
<br>
<br>

    <div class="row">
	  <div class="col-lg-12">
		 	<div class="table-responsive"></div>
		 		<table style="margin-top: 15px; width: 100%;" class="table table-bordered table-striped" id="dtHorizontalVerticalScrollExample" cellspacing="0">
		 			<thead>
			 			<tr>
			 				<th style="width: 5%;">No</th>
			 				<th style="width: 10%;">Code Penyakit</th>
			 				<th style="width: 10%;">Nama Penyakit</th>
			 				<th style="width: 80px;">Isi Content</th>
			 				<th style="width: 10%;">Jenis Penyakit</th>
			 				<th style="width: 5%;">Gambar</th>
			 				<th style="width: 10%">Opsi</th>
			 			</tr>
		 			</thead>	
		 			<tbody>
		 				
		 				 <?php
		 				 	function limit_words($string, $word_limit){
						    $words = explode(" ",$string);
						    return implode(" ",array_splice($words,0,$word_limit));
							}

		 				 	$no = 1;
		 					if(mysqli_num_rows($jenis_penyakit)>0){
		 					while ($data  = mysqli_fetch_array($jenis_penyakit)){
		 					
		 				 ?>
			 			<tr>
			 				<td><center><?php echo $no++; ?>.</center></td>
			 				<td><?php echo $data['code_penyakit']; ?></td>
			 				<td><?php echo $data['nama_penyakit'] ?></td>
			 				<td style="overflow: hidden;text-overflow: ellipsis;"><?php echo limit_words($data['spesifikasi'],50); ?></td>
			 				<td><?php echo $data['jenis_penyakit']; ?></td>
			 				<td>
			 					<img src="../assets/images/penyakit/<?php echo $data['gambar']; ?>" style="width: 90px; height: 80px;">
			 				</td>
			 				<td>
			 					<a href="?page=edit_jp&id=<?php echo $data['id_penyakit']; ?>"><button type="button" class="btn btn-info"><i class="fas fa-edit"></i></button></a>
			 					<a href="?page=hapus_jp&id=<?php echo $data['id_penyakit']; ?>"><button type="button" class="btn btn-danger"><i class="fas fa-trash-alt"></i></button>
			 				</td>
			 			</tr>
			 			<?php }
			 			}else{
			 				echo "<tr><td colspan=\"10\"align=\"center\">Data Tidak Ditemukan</td></tr>";
			 			}
			 			?>
			 			
			 		</tbody>
		 		</table>
	 	</div>

