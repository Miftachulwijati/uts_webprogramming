<body>
	<?php require '_partials/navbar.php'?>
 	
	<!-- Page Content -->
	<?php
	$content = (isset($_GET["page"])) ? $_GET["page"] : "" ;		
		switch ($content) {
		
		case 'profil':
			echo "<title>Profil</title>";
			require 'content/profil.php';
			break;
		case 'contact':
			echo "<title>Profil</title>";
			require 'content/contact.php';
			break;
		case 'jp':
			echo "<title>Gejala Sakit</title>";
			require 'content/penyakit.php';
			break;
		case 'detail_jp':
			require 'content/detail_penyakit.php';
			break;
		case 'mcm_obat':
			echo "<title>Macam - Macam Obat</title>";
			require 'content/macam_obat.php';
			break;
		case 'detail_obat':
			require 'content/detail_obat.php';
			break;
		case 'tips':
			require 'content/tips.php';
			break;
		case 'contact':
			echo "<title>Profil</title>";
			require 'content/contact.php';
			break;
		default:
 			echo"<title>Home</title>";
 			require 'content/home.php';
 			break;
		}
	?>
	 	<!-- /.row -->
	 	
	<!-- /.container -->
	<?php require '_partials/footer.php'; ?>
	
</body>