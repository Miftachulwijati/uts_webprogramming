-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2019 at 11:25 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_apotek`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id_contact` int(11) NOT NULL,
  `facebook` text NOT NULL,
  `whatsapp` text NOT NULL,
  `link_whatsapp` text NOT NULL,
  `instagram` text NOT NULL,
  `email` text NOT NULL,
  `location` text NOT NULL,
  `link_location` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id_contact`, `facebook`, `whatsapp`, `link_whatsapp`, `instagram`, `email`, `location`, `link_location`) VALUES
(1, 'https://www.facebook.com/messages/t/dimas213', '6287869966215', 'https://wa.me/087869966215', 'https://www.instagram.com/mas_andika34/', 'andikapanji12@gmail.com', 'Jl. Mataram No.9, Kel. pesurungan lor, Kel. Pesurungan Lor, Pesurungan Lor, Kec. Margadana, Kota Tegal, Jawa Tengah 52147\"', 'https://www.google.com/maps/place/Jl.+Mataram,+Kota+Tegal,+Jawa+Tengah/@-6.8674797,109.1080103,21z/data=!4m5!3m4!1s0x2e6fb759739666d9:0x566e9c76baea7059!8m2!3d-6.8611938!4d109.108467\"');

-- --------------------------------------------------------

--
-- Table structure for table `data_profilweb`
--

CREATE TABLE `data_profilweb` (
  `id` int(11) NOT NULL,
  `profil` text NOT NULL,
  `visi` text NOT NULL,
  `misi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_profilweb`
--

INSERT INTO `data_profilweb` (`id`, `profil`, `visi`, `misi`) VALUES
(1, 'ApotekMAT adalah layanan web yang menyediakan informasi tentang jenis - jenis penyakit, jenis - jenis obat dan informasi kesehatan dalam kehidupan sehari - hari.', 'Menjadi layanan terbaik, yang mengutamakan pelayanan dan kenyamanan yang memuaskan bagi pengunjung website dalam mencari informasi dunia kesehatan.', '1. Melakukan konseling yang baik kepada pasien.\r\n2. Menyediakan obat-obatan dengan kualitas yang baik.\r\n3. Memberikan pelayanan kesehatan yang optimal.\r\n4. Menjadikan rakyat Indonesia menjadi rakyat yang sehat, khususnya dalam bidang jasmani.\r\n5. Membuka hubungan baik antara pasien dan apoteker.');

-- --------------------------------------------------------

--
-- Table structure for table `jenis_penyakit`
--

CREATE TABLE `jenis_penyakit` (
  `id_jp` int(11) NOT NULL,
  `kode_jp` varchar(255) NOT NULL,
  `nama_jenis` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jenis_penyakit`
--

INSERT INTO `jenis_penyakit` (`id_jp`, `kode_jp`, `nama_jenis`) VALUES
(1, 'K001', 'Kulit');

-- --------------------------------------------------------

--
-- Table structure for table `obat`
--

CREATE TABLE `obat` (
  `id_obat` int(11) NOT NULL,
  `code_obat` varchar(255) NOT NULL,
  `barcode` varchar(255) NOT NULL,
  `nama_obat` varchar(255) NOT NULL,
  `jenis_obat` varchar(255) NOT NULL,
  `spesifikasi` text NOT NULL,
  `harga_beli` float NOT NULL,
  `harga_jual` float NOT NULL,
  `satuan` varchar(255) NOT NULL,
  `stok` int(11) NOT NULL,
  `tgl_expired` date NOT NULL,
  `supplier` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `indikasi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `obat`
--

INSERT INTO `obat` (`id_obat`, `code_obat`, `barcode`, `nama_obat`, `jenis_obat`, `spesifikasi`, `harga_beli`, `harga_jual`, `satuan`, `stok`, `tgl_expired`, `supplier`, `gambar`, `indikasi`) VALUES
(1, 'B001', '17090142', 'paracetamol', 'demam', 'Paracetamol bekerja dengan cara mengurangi produksi zat penyebab peradangan, yaitu prostaglandin. Dengan penurunan kadar prostaglandin di dalam tubuh, tanda peradangan seperti demam dan nyeri akan berkurang.\r\nBelum ada laporan mengenai terjadinya cacat janin ketika paracetamol digunakan oleh ibu hamil. Untuk ibu menyusui, penggunaan paracetamol dapat terserap ke dalam ASI, tetapi dalam jumlah kecil. Konsultasikan lebih lanjut dengan dokter untuk mengetahui manfaat dan risiko konsumsi paracetamol pada saat hamil atau menyusui. \r\n\r\nMerk dagang paracetamol: Panadol, Naprex, Paramol, Mixagrip Flu, Hufagesic, Paramex SK, Sanmol, Tempra, Termorex, dan Poro. \r\nApa Itu Paracetamol? \r\nGolongan      Oban penurun panas dan pereda nyeri (analgesik dan antipiretik) \r\nKategori      Obat bebas \r\nManfaat      Meredakan rasa sakit dan demam \r\nDikonsumsi oleh      Dewasa dan anak-anak \r\nKategori kehamilan dan menyusui \r\n     Obat minum dan suppositoria \r\nKategori B: Studi pada binatang percobaan tidak memperlihatkan adanya risiko terhadap janin, namun belum ada studi terkontrol pada wanita hamil. \r\n\r\nInfus dan suntik \r\nKategori C: Studi pada binatang percobaan memperlihatkan adanya efek samping terhadap janin, namun belum ada studi terkontrol pada wanita hamil. Obat hanya boleh digunakan jika besarnya manfaat yang diharapkan melebihi besarnya risiko terhadap janin. \r\nParacetamol dapat terserap ke dalam ASI. Bila Anda sedang menyusui, lebih baik berkonsultasi dengan dokter terlebih dahulu. \r\nBentuk obat      Tablet, kaplet, sirup, drop, infus, dan suppositoria. \r\nPeringatan Sebelum Mengonsumsi Paracetamol (Acetaminophen) \r\n\r\n   Konsultasikan dengan dokter sebelum menggunakan paracetamol jika Anda menderita gangguan ginjal atau hati. \r\n   Jangan memberikan paracetamol kepada anak berusia di bawah 2 tahun tanpa petunjuk dari dokter. \r\n   Konsumsi alkohol bersama paracetamol dapat meningkatkan risiko kerusakan hati pada pengunanya. \r\n   Beritahukan segala jenis obat, suplemen, ataupun obat herbal ke dokter, terutama jika Anda menggunakan obat untuk epilepsi atau tuberkulosis (TBC), serta obat pengencer darah. \r\n   Segera ke rumah sakit jika gejala yang diderita bertambah parah atau berkepanjangan, serta ketika muncul kemerahan pada kulit. \r\n   Segera ke dokter jika terjadi alergi atau overdosis. \r\n\r\nDosis dan Aturan Pakai Paracetamol (Acetaminophen) \r\n\r\nDosis dari paracetamol disesuaikan dengan usia dan kondisi penderita. Berikut adalah penjelasannya: \r\nBentuk: Obat minum dan suppositoria \r\n\r\nIndikasi dan kegunaan: Meredakan demam dan nyeri \r\n\r\n   Dewasa \r\n   325-650 mg tiap 4-6 jam atau 1.000 mg tiap 6-8 jam. \r\n   Paracetamol biasanya tersedia dalam bentuk tablet dengan kandungan 500 mg. Paracetamol 500 mg dapat diminum tiap 4-6 jam sekali untuk meredakan demam. \r\n   Anak < 2 bulan \r\n   10-15 mg/kgBB, tiap 6-8 jam sekali atau sesuai dengan anjuran dokter. \r\n   Anak 2 bulan - 12 tahun \r\n   10-15 mg/kgBB, tiap 4-6 jam sekali atau sesuai anjuran dokter. Dosis maksimal 5 kali pemberian dalam 24 jam. \r\n   Anak > 12 tahun \r\n   325-650 mg per 4-6 jam atau 1.000 mg tiap 6-8 jam. \r\n   Untuk paracetamol infus, dosis paracetamol akan sesuai dengan anjuran dari dokter. \r\n\r\nCara Menggunakan Paracetamol (Acetaminophen) dengan Benar \r\n\r\nPastikan Anda selalu menggunakan paracetamol sesuai aturan pakai yang tertera di kemasan obat atau anjuran dokter. Hentikan penggunaan paracetamol jika keluhan tidak reda setelah 3 hari mengonsumsi paracetamol. \r\n\r\nParacetamol tablet dan sirup \r\n\r\nGunakan segelas air putih untuk menelan tablet paracetamol. Untuk paracetamol sirup, gunakan sendok takar agar dosis yang dikonsumsi tepat. Sebelum itu, pastikan Anda mengocok sirup terlebih dahulu. \r\n\r\nSimpanlah paracetamol dalam suhu ruangan, terhindar dari panas dan lembab, serta hindarkan dari jangkauan anak-anak. \r\n\r\nParacetamol suppositoria \r\n\r\nParacetamol bentuk suppositoria digunakan dengan cara dimasukkan ke dalam anus. Pastikan Anda membuka plastik pembungkusnya terlebih dahulu kemudian masukkan obat bagian ujung yang lancip ke dalam dubur. Setelah obat masuk, duduk atau tiduran terlebih dahulu hingga obat meleleh. Jangan lupa cuci tangan sebelum dan sesudah memasukkan obat suppositoria. Paracetamol suppositoria perlu disimpan di dalam kulkas. \r\n\r\nParacetamol infus \r\n\r\nParacetamol dalam bentuk infus hanya diberikan oleh petugas medis. Sebelum menggunakan paracetamol dengan bentuk lainnya, pastikan Anda membaca petunjuk yang tertera di kemasan obat atau sesuai petunjuk dokter. \r\nInteraksi Paracetamol (Acetaminophen) dengan Obat Lain \r\n\r\nParacetamol dapat berinteraksi jika digunakan dengan obat lainnya. Berikut ini beberapa interaksi yang dapat terjadi: \r\n\r\n   Meningkatkan risiko perdarahan, jika digunakan bersamaan dengan warfarin. \r\n   Menurunkan efek paracetamol, jika digunakan dengan carbamazepine, phenytoin, phenobarbital, cholestyramine, dan imatinib. \r\n   Meningkatkan efek samping obat busulfan. \r\n   Meningkatkan kemungkinan munculnya efek samping paracetamol, jika digunakan dengan metoclopramide, domperidone, atau atau probenecid. \r\n\r\nEfek Samping dan Bahaya Paracetamol (Acetaminophen) \r\n\r\nParacetamol jarang menyebabkan efek samping. Namun, paracetamol bisa menimbulkan beberapa efek samping berikut jika digunakan secara berlebihan: \r\n\r\n   Demam \r\n   Muncul ruam kulit yang terasa gatal \r\n   Sakit tenggorokan \r\n   Muncul sariawan \r\n   Nyeri punggung \r\n   Tubuh terasa lemah \r\n   Kulit atau mata berwarna kekuningan \r\n   Timbul lebam pada kulit \r\n   Urine berwarna keruh atau berdarah \r\n   Tinja berwarna hitam atau BAB berdarah \r\n\r\nJika dikonsumsi secara berlebihan, paracetamol bisa menyebabkan overdosis, dengan gejala berupa: \r\n\r\n   Perut bagian atas terasa sakit \r\n   Kehilangan nafsu makan \r\n   Mual atau muntah \r\n   Diare \r\n   Keringat dingin', 8000, 10000, 'pcs', 50, '2020-11-03', 'PT. Indofarma', 'paracetamol.jpg', 'demam, meriang, nyeri, flu, pusing'),
(2, 'B002', '17090002', 'Acrios', 'Antidiabetes', 'Obat anti Diabetes yang digunakan untuk menangani Diabetes tipe 2, bekerja dengan cara memperlambat proses pencernaan karbohidrat menjadi senyawa Karbohidrat lebih sederhana sehingga membantu menurunkan kadar gula dalam darah setelah makan.', 50000, 55000, 'Tablet', 200, '2019-11-14', 'PT. Kimia Farma', 'Acrios.jpg', 'Daya tahan Tubuh lemah, Pusing, Lesu'),
(3, 'B003', '17090003', 'Nytex', 'Obat Dahak', 'Mengencerkan Dahak yang menghalangi saluran pernapasan', 10000, 12000, 'Kapsul', 20000, '2019-11-29', 'PT. Kimia Farma', 'Nytex.jpg', 'Batuk Berkepanjangan disertai Dahak'),
(4, 'B004', '17090004', 'Acifar', 'Inveksi Virus', 'Obat yang dapat digunakan untuk mengobati Inveksi Virus seperti Varicella Zoster dan Herpes Simplex', 120000, 150000, 'Tablet dan Sirop', 4000, '2019-11-30', 'PT Kimia Farma', 'Acifar.jpg', 'Nyeri dan Gatal karena Infeksi'),
(5, 'JB0005', '17090005', 'Alendion', 'Obat Kulit', 'Mencegah Peradangan dan penyumbatan pori kulit akibat sel-selkulit mati dan penumpukan minyak', 78000, 80000, 'Keim, gel', 12000, '2019-11-27', 'PT Kimia Farma', 'Alendion.jpg', 'Peradangan dan penyumbatan pada kulit dan minyak berlebih'),
(6, 'B006', '17090006', 'Bacitrain Polymyxin B', 'Antibiotik Topikal', 'Digunakan untuk mengobati kulit Infeksi dan infeksi Bakteri pada saat terjadi luka ringan di kulit, seperti luka bakar kecil', 56000, 57000, 'Krim, Salep, Serbuk', 8990, '2019-11-20', 'PT Kimia Farma', 'Bacitrain Polymyxin B.JPG', 'Kulit Iritasi ringa'),
(7, 'B007', '17090007', 'Busulfex', 'komoterapi Sitotoksik', 'Obat Kemoterapi untuk menangani Kanker', 50000, 60000, 'Oral dan Suntikan Intervena', 90000, '2019-11-30', 'PT Kimia Farma', 'Busulfex.jpg', 'Digunakan bagi Pasien pengidap gejla Kanker'),
(8, 'B008', '17090008', 'Calcit', 'Analog Vitamin D', 'Mengatasi dan mencegah kekurangan kalsium dan penyakit tulang pada penderita gangguan fugsi ginjal dan kelenar paratiroid', 80000, 89000, 'Kapsul', 90000, '2019-11-28', 'PT Kimia Farma', 'Calcit.jpg', 'Sakit Tulang, Persendian'),
(9, 'B009', '17090009', 'Candefion', 'Obat Hipertensi', 'Bermanfaat untuk tekanan darah tinggi', 45000, 50000, 'Tablet', 78000, '2019-11-13', 'PT Kimia Farma', 'Candefion.jpg', 'Badan terasa lemas dan Sesak Nafas'),
(10, 'B010', '17090010', 'Deermatix Ultra', 'Obat Kulit', 'Obat Luar membantu menghaluskan bekas luka', 25000, 30000, 'Gel', 89000, '2019-11-27', 'PT Kimia Farma', 'Dermatix Ultra.jpg', 'Bekas luka kering di KulitDslo'),
(11, 'B011', '17090011', 'Desloratadine', 'Obat Alergi', 'Obat ini bekerja dengan menghambat efek histamin yaitu zat alami didalam tubuh yang dapat menyebabkan reaksi Alergi', 10000, 15000, 'Tablet dan Sirop', 78000, '2019-11-15', 'PT Kimia Farma', 'Desloratadine.jpg', 'Bersin, Pileg, biduran, mata gatal, mata merah, mata berair serta sesak nafas'),
(12, 'B012', '17090012', 'EM Kapsul', 'Obat Haid', 'Melancarkan Menstruasi dan Nyeri Haid', 5000, 6000, 'Kapsul', 78000, '2019-11-15', 'Indusstri Jamu Borobudur', 'EM Kapsul.jpg', 'Nyeri saat Haid'),
(13, 'B013', '17090013', 'Enervon C', 'Multivitamin', 'Suplemen untuk membantumenjaga daya tahan tubuh', 25000, 30000, 'Tablet, Sirup dan Tablet effervescent', 78000, '2019-11-28', 'PT Kimia Farma', 'Enervon C.jpg', 'Lemah, lesu ,badan cepat letih ,daya tahan tubuh kurang Fit'),
(14, 'B014', '1709014', 'Famotidine', 'Obat Maag', 'PT Kimia Farma', 10000, 15000, 'Tablet Kunyah, Kaplet', 67000, '2019-11-30', 'PT Kimia Farma', 'Famotidine.jpeg', 'Sakit Perut sampai ke Ulu Hati'),
(15, 'B015', '17090015', 'Feminax', 'Obat Haid', 'Meredahan Kram Perut dan Nyeri Haid', 12000, 15000, 'Tablet Minum', 56000, '2019-11-20', 'PT Kimia Farma', 'Feminax.jpg', 'Sakit Haid pada bagian perut dan sekitarnay'),
(16, 'B016', '17090016', 'Glycerol', 'Obat Sakit Perut', 'Digunakan untuk mengatasi Kontipasi atau buang air besar secara sementara', 7000, 8000, 'Suppositiria, cairan enema', 67000, '2019-11-14', 'PT Kimia Farma', 'Glycerol.jpg', 'Sakit Perut'),
(17, 'B017', '17090017', 'Haloperidol', 'Obat Gangguan Psiklogi', 'Mengatasi Gejala Psikosis pada gangguan Mental seperti Skizofrenia', 18000, 20000, 'Tablet, Obat Tetes Mulut dan Suntik', 89000, '2019-11-21', 'PT Kimia Farma', 'Haloperidol.jpg', 'Gangguan Mental, Gelisah, Agresif'),
(18, 'B018', '1700018', 'Iprox', 'Obat Nyeri', 'Meredakan peradanagan dan nyeri pada tubuh yang diakibatkan penyakit tertentu', 67000, 70000, 'Oral, Topikal, Suntik(intravena)', 67000, '2019-11-22', 'PT Kimia Farma', 'Iprox.jpg', 'Sakit Kepala, Skit Gigi, Nyeri Punggung, Radang Sendi, Nyeri Haid'),
(19, 'B019', '17090018', 'Kalipar', 'Suplemen Mineral', 'Mengobati dan mencegah kekurangan kalium', 90000, 10000, 'Tablet, Cair, Suntik', 67000, '2019-11-26', 'PT Kimia Farma', 'Juvelon B.jpg', 'Kelelahan Otot, mual, muntah, perubahan suasana hati, gangguan irama Jantung'),
(20, 'B020', '17090020', 'Olium', 'Pelembab Kulit', 'Mencegah dan mengatasi kulit kering, gatal dan Iritasi', 67000, 70000, 'Obat Oles', 56000, '2019-11-28', 'PT Kimia Farma', 'Kalipar.jpg', 'Kulit Kering, Gatal, Iritasi'),
(21, 'B021', '17090021', 'Lacto-B', 'Probiotik', 'Mencegah dan mengobati Diare dan Mengurangi gejala intolerasi Laktosa', 56000, 80000, 'Bubuk dan Sachet', 78000, '2019-11-14', 'PT Kimia Farma', 'Lacto-B.jpg', 'Diare, Sakit Perut'),
(22, 'B022', '17090022', 'Microlax', 'Obat Pencahar', 'Mengatasi Konstipasi dan tindakan pembersihan Usus sebelum tindakan Medis di Area Usus', 15000, 20000, 'Serbuk,Cairan', 56000, '2019-11-20', 'PT Kimia Farma', 'Microlax.jpg', 'Perut Sembelit'),
(23, 'B023', '17090023', 'Panadol', 'Obat Sakit Kepala', 'Obat nyeri dan Penurun Demam', 1000, 2000, 'Kaplet', 90000, '2019-11-28', 'PT Kimia Farma', 'Panadol.jpg', 'Sakit Kepala, Demam'),
(24, 'B024', '170900024', 'Q Ten', 'Vitamin dan Suplemen', 'Katalis Alami  untuk menghasilkan energi dari makanan dan Antioksidan', 20000, 25000, 'Botol isi 30 Kapsul', 4000, '2019-11-14', 'Novell Pharmaceutical Laboratories', 'Q Ten.jpg', 'Lemas, letih, lesu dan Kurang bersemangat'),
(25, 'B025', '17090025', 'Juvelon B', 'Suplemen', 'menjaga agar sirkulasi pada sistem Parifer menjadi lancar', 19000, 20000, 'Kaplet', 10000, '2019-11-22', 'PT Kimia Farma', 'Juvelon B.jpg', 'Lemas, letih dan Lesu'),
(26, 'B026', '17090026', 'Ramipril', 'Obat Hipertensi', 'Mengatasi Hipertensi dengan cara Menghambat Hormon yang merubah Angiotensin l menjadi Angiostensin ll', 60000, 80000, 'Tablet, Kaplet', 6000, '2019-11-18', 'PT Kimia Farma', 'Ramipril.jpg', 'Badan Lesu, Sesak Nafas'),
(27, 'B027', '17090027', 'Salbuven', 'Obat Asma', 'Meringankan Gejala Asma dan PPOK bekerja dengan caramelemaskan Otot-otot disekitar saluran perapasan yang menyempit sehingga Udara dapat mengalir lebih lancar ke dalam Paru-paru', 70000, 80000, 'Obat Hirup, Obat Infus, Tablet, Infus', 88000, '2019-11-24', 'PT Kimia Farma', 'Salbuven.jpg', 'Sesak Nafas, Asma'),
(28, 'B028', '17090028', 'Tamofen', 'Terapi Hormonal', 'Obat untuk menangani Kanker Payudara', 200000, 250000, 'Tablet Salut Selaput', 45000, '2019-11-26', 'PT Kimia Farma', 'Tamofen.jpg', 'Kanker Payudara'),
(29, 'B029', '1700029', 'Vaksin BCG Kering', 'Vaksin', 'Melindungi diri dari Tuber Kolosis', 150000, 180000, 'Obat Suntik', 78000, '2019-11-22', 'PT Kimia Farma', 'Vaksin BCG Kering.png', 'Batuk'),
(30, 'B030', '17090030', 'Warfarin', 'Obat Penggumpalan Darah', 'Mengatasai dan Mencegah Pengumpalan Darah', 500000, 600000, 'Tablet', 8900, '2019-11-28', 'PT Kimia Farma', 'Warfarin.jpg', 'Dada Sakit, Strok31'),
(31, 'B031', '17090031', 'Xananx', 'Obat Penenang', 'Mengatasi Gangguan Kecemasan dan Gangguan Panik', 90000, 100000, 'Kaplet dan Tablet', 45000, '2019-11-28', 'PT Kimia Farma', 'Xananx.jpg', 'Cemas, panik'),
(32, 'B032', '17090032', 'Zircum Kid', 'Mineral', 'Mineral yang membantu penyembuhan luka, berperan dalam indera perasa dan penciuman, memperkuat sistem kekebalan tubuh, membantu pertumbuhan sel, serta mengurangi Karbohidrat', 89000, 90000, 'Infus dan Tablet', 90000, '2019-11-28', 'PT Kimia Farma', 'Zircum Kid.jpg', 'Diare, Sirosis'),
(33, 'JB0033', '17090033', 'Sakit Hati', 'Cinta', 'Obat yang dapat menyembuhkan sakit hati. Dengan langkah :\r\n1. Wudhu,\r\n2. Shalat,\r\n3. Dzikir,\r\n4. Doa,\r\n5. Membaca Al-Qur`an', 100000, 110000, 'Buku', 50, '9999-12-31', 'Mentri Agama Islam', 'Al-Quran.jpg', 'sakit di dada, tidak terlihat.');

-- --------------------------------------------------------

--
-- Table structure for table `penyakit`
--

CREATE TABLE `penyakit` (
  `id_penyakit` int(11) NOT NULL,
  `code_penyakit` varchar(255) NOT NULL,
  `nama_penyakit` varchar(255) NOT NULL,
  `spesifikasi` text NOT NULL,
  `jenis_penyakit` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penyakit`
--

INSERT INTO `penyakit` (`id_penyakit`, `code_penyakit`, `nama_penyakit`, `spesifikasi`, `jenis_penyakit`, `gambar`) VALUES
(1, 'JP0001', 'Alergi Makanan', 'Alergi makanan terjadi ketika sistem kekebalan tubuh menganggap protein di dalam makanan merupakan suatu ancaman bagi tubuh. Sebagai bentuk respons, tubuh melepaskan senyawa kimia yang memicu reaksi alergi.\r\nReaksi yang timbul dari alergi makanan sering kali ringan. Namun pada beberapa kasus, alergi makanan bisa sampai mengancam nyawa. Oleh karena itu, penting untuk mengetahui cara mencegah dan meredakan reaksi alergi yang muncul.\r\nGejala Alergi Makanan\r\n\r\nPada sebagian orang, alergi makanan dapat menyebabkan penderitanya merasa tidak nyaman meski tidak terlalu parah. Gejala sering kali muncul dalam beberapa menit sampai dua jam setelah mengonsumsi makanan pemicu alergi.\r\n\r\nGejala alergi makanan yang muncul sama dengan reaksi alergi pada umumnya, yaitu:\r\n\r\n    Pilek atau hidung tersumbat.\r\n    Ruam kulit yang terasa gatal.\r\n    Gatal di mulut, tenggorokan, mata, dan di bagian tubuh lain.\r\n    Pembengkakan pada wajah, bibir, lidah, atau tenggorokan.\r\n    Sulit menelan dan berbicara.\r\n    Mengi atau bengek.\r\n    Sesak napas.\r\n\r\nPenderita alergi makanan juga dapat merasakan gejala di saluran pencernaan, seperti sakit perut, diare, mual, dan muntah.\r\nKapan harus ke dokter\r\n\r\nPeriksakan diri Anda atau anak Anda ke dokter bila muncul gejala di atas setelah mengonsumsi makanan tertentu. Beri tahu dokter mengenai makanan yang baru dikonsumsi.\r\n\r\nPada beberapa orang, alergi makanan dapat memicu reaksi alergi serius yang disebut anafilaksis. Berikan suntikan epinephrine dan segera ke IGD bila muncul gejala anafilaksis, seperti:\r\n\r\n    Jantung berdebar\r\n    Pusing dan pandangan gelap\r\n    Keringat dingin\r\n    Hilang kesadaran\r\n\r\nKonsultasikan dengan dokter anak mengenai kemungkinan anak terkena alergi dan hal yang perlu diwaspadai bila terdapat keluarga yang menderita penyakit alergi, seperti alergi makanan, asma, atau rinitis alergi.\r\n\r\nPenyebab Alergi\r\n\r\nAlergi makanan terjadi ketika sistem kekebalan tubuh keliru menganggap protein di dalam makanan tertentu sebagai ancaman bagi tubuh. Guna meresponsnya, tubuh melepaskan antibodi yang disebut imunoglobulin E (IgE), guna menetralisir pemicu alergi (alergen) di dalam makanan tersebut.\r\n\r\nKetika seseorang kembali mengonsumsi makanan tersebut meski hanya sedikit, IgE akan merangsang tubuh untuk mengeluarkan senyawa kimia yang disebut histamin ke aliran darah. Histamin inilah yang menyebabkan timbulnya gejala alergi.\r\n\r\nAlergi makanan biasanya berlangsung sejak masa kanak-kanak, tetapi kadang juga baru muncul ketika seseorang sudah dewasa. Makanan yang menyebabkan alergi cenderung berbeda pada orang dewasa dan anak-anak.\r\n\r\nPada orang dewasa, reaksi alergi bisa muncul setelah mengonsumsi makanan berikut:\r\n\r\n    Ikan\r\n    Kerang\r\n    Udang\r\n    Kepiting\r\n    Kacang-kacangan\r\n\r\nSedangkan pada anak-anak, makanan yang umum menyebabkan alergi antara lain:\r\n\r\n    Kacang\r\n    Gandum\r\n    Kedelai\r\n    Telur\r\n    Susu sapi\r\n\r\nBelum diketahui mengapa pada beberapa kasus, alergi makanan baru muncul saat usia dewasa.\r\nFaktor Risiko Alergi Makanan\r\n\r\nAlergi makanan lebih berisiko dialami oleh orang yang menderita alergi lain, seperti rinitis alergi atau asma. Orang yang sudah terkena alergi pada satu jenis makanan juga lebih rentan menderita alergi pada jenis makanan lain.\r\n\r\nFaktor lain yang dapat meningkatkan risiko seseorang terserang alergi makanan adalah:\r\n\r\n    Berusia di bawah lima tahun.\r\n    Memiliki keluarga yang menderita riwayat alergi, seperti biduran atau asma.\r\n\r\nDiagnosis Alergi Makanan\r\n\r\nUntuk menentukan alergi makanan, dokter menanyakan gejala yang dialami pasien, makanan apa yang dikonsumsi sebelum gejala muncul, serta riwayat kesehatan pasien dan keluarganya. Setelah itu, pemeriksaan fisik akan dilakukan untuk membedakan gejala alergi makanan dengan gejala pada kondisi lain.\r\n\r\nSelanjutnya, dokter akan menjalankan tes alergi yang meliputi:\r\nTes alergi kulit\r\n\r\nDalam tes alergi pada kulit, kulit pasien akan ditusuk dengan jarum kecil. Setelah itu, dokter akan memasukkan sedikit protein pada makanan yang diduga menyebabkan alergi ke area kulit yang ditusuk tadi untuk melihat reaksinya.\r\nTes darah\r\n\r\nSampel darah pasien akan diambil untuk mengukur kadar imunoglobulin E (IgE) spesifik. Bila kadar IgE yang terkait makanan tertentu cukup tinggi dalam darah pasien, artinya pasien memiliki alergi terhadap makanan tersebut.\r\nTes makanan\r\n\r\nPasien akan diminta menghindari jenis makanan yang diduga menjadi penyebab alergi selama 1-2 minggu. Jika pasien alergi terhadap jenis makanan tadi, maka dalam kurun waktu tersebut pasien tidak akan mengalami reaksi alergi, dan akan kembali mengalaminya bila makanan tersebut kembali dikonsumsi.\r\n\r\nDokter juga dapat meminta pasien mengonsumsi makanan yang dicurigai sebagai pemicu alergi dalam porsi kecil, kemudian porsinya ditingkatkan secara perlahan. Jika tidak muncul reaksi alergi selama tes berlangsung, maka pasien diperbolehkan mengonsumsi makanan tersebut.\r\nPengobatan Alergi Makanan\r\n\r\nCara terbaik untuk mengatasi alergi makanan adalah dengan menghindari makanan penyebab alergi. Meski demikian, seseorang mungkin saja mengonsumsi makanan tersebut secara tidak sengaja. Bila hal ini terjadi, ada beberapa obat yang bisa digunakan untuk meredakan gejala.\r\n\r\nJika gejala yang muncul tergolong ringan, penderita bisa menggunakan antihistamin yang dijual bebas. Bila gejala masih terasa, penderita bisa ke dokter agar diberikan antihistamin dengan dosis lebih tinggi.\r\n\r\nBila muncul gejala anafilaksis, penderita harus dibawa ke IGD rumah sakit untuk diberikan suntikan epinephrine. Setelah gejala hilang, dokter akan meminta pasien untuk selalu membawa suntikan tersebut.\r\n\r\nPenting untuk memahami cara menggunakan suntik epinephrine, bila gejala alergi makanan yang Anda alami cukup parah. Selain itu, ajari juga orang-orang yang sering berada di dekat Anda, misalnya keluarga atau rekan kerja, mengenai cara menggunakan suntikan tersebut bila Anda terserang anafilaksis.\r\n\r\nPastikan untuk mengganti epinephrine sebelum masa kedaluwarsa, dan ganti alat suntiknya bila sudah tidak berfungsi dengan baik.\r\nKomplikasi Alergi Makanan\r\n\r\nPada kasus yang parah, alergi makanan dapat menyebabkan anafilaksis, yaitu reaksi alergi yang dapat berbahaya. Anafilaksis dapat berlangsung beberapa menit bahkan detik setelah terpapar pemicu alergi.\r\nPencegahan Alergi Makanan\r\n\r\nCara mencegah reaksi alergi makanan adalah dengan menghindari makanan yang dapat memicu alergi. Hal ini mungkin sedikit merepotkan bagi penderita, tetapi tetap perlu dilakukan untuk menghindari kondisi yang lebih serius.\r\n\r\nLakukan langkah-langkah berikut ini guna mencegah reaksi akibat alergi makanan:\r\n\r\n    Baca kandungan apa saja yang terdapat pada tiap kemasan makanan yang hendak dikonsumsi.\r\n    Bawa makanan ringan bebas alergi jika ingin ke luar rumah. Hal ini akan membantu bila Anda sulit menemukan makanan bebas alergi\r\n    Bila ingin makan di restoran, beritahu pelayan atau juru masak tentang makanan apa saja yang tidak boleh dikonsumsi.\r\n    Pastikan makanan yang dibeli di luar tidak diolah dan disajikan di tempat yang sebelumnya digunakan untuk mengolah makanan pemicu alergi.\r\n\r\nAnda juga perlu mengenakan gelang khusus yang mencantumkan bahwa Anda menderita alergi makanan. Gelang ini akan membantu saat muncul reaksi alergi dan Anda kesulitan untuk berkomunikasi. Bila reaksi alergi makanan cukup parah, konsultasikan dengan dokter tentang perlunya membawa suntik epinephrine.', 'Kulit', 'alergi-makanan.jpg'),
(2, 'JP0002', 'bisul', 'benjolan merah pada kulit yang terasa sakit dan berisi nanah. Benjolan ini muncul akibat infeksi bakteri yang memicu peradangan pada folikel rambut, yaitu lubang tempat tumbuhnya rambut.\r\n\r\nBagian tubuh yang paling sering terkena bisul adalah wajah, leher, ketiak, bahu, bokong, dan paha. Ini terjadi karena bagian-bagian tersebut sering mengalami gesekan dan berkeringat. Selain itu, bisul juga bisa tumbuh pada kelopak mata. Kondisi inilah yang biasanya kita kenal dengan istilah bintitan.\r\n\r\nGejala Bisul\r\nGejala utama pada bisul adalah munculnya benjolan merah pada kulit. Pada tahap awal, ukuran bisul biasanya kecil dan kemudian disertai dengan:\r\n\r\nKulit di sekitar benjolan memerah, bengkak, dan terasa hangat jika disentuh. Ini mengindikasikan bahwa infeksi telah menyebar ke kulit sekelilingnya.\r\nBenjolan bertambah besar dan berisi nanah.\r\nTerbentuk titik putih di bagian puncak benjolan.\r\n', 'kulit', 'bisul.jpg'),
(3, 'JP0003', 'campak', 'Rubeola, atau yang lebih dikenal dengan penyakit campak adalah infeksi menular yang disebabkan oleh virus. Sebelum imunisasi campak digalakkan, campak adalah salah satu penyakit endemik yang menyebabkan kematian terbanyak setiap tahunnya.\r\n\r\nPenyakit ini disebabkan oleh virus dalam keluarga paramyxovirus yang biasanya ditularkan melalui kontak langsung dengan penderita atau lewat udara. Virus menginfeksi saluran pernapasan dan kemudian menyebar ke seluruh tubuh.\r\n\r\nGejala spesifik dari penyakit ini adalah ruam kulit berwarna kemerahan yang muncul 7-14 hari setelah paparan dan dapat bertahan selama 4-10 hari. Pada anak-anak, penyakit ini bisa menyebabkan komplikasi serius yang mematikan jika tidak ditangani dengan baik. Oleh sebab itu, segera konsultasi ke dokter atau penyedia layanan kesehatan terdekat jika Anda atau anak Anda mengalami penyakit ini.', 'demam', 'campak.jpg'),
(4, 'JP0004', 'Demam Bedarah (DBD)', 'Demam berdarah atau demam berdarah dengue (DBD) adalah penyakit yang disebabkan oleh infeksi virus Dengue. Virus ini masuk ke dalam tubuh manusia melalui gigitan nyamuk Aedes aegypti dan Aedes albopictus, yang hidup di wilayah tropis dan subtropis. Diperkirakan terdapat setidaknya 50 juta kasus demam berdarah di seluruh dunia tiap tahunnya.\r\nMenurut data yang dihimpun Kementerian Kesehatan Republik Indonesia, demam berdarah telah menjadi penyakit endemik di Indonesia sejak tahun 1968. Sejak itu, penyakit ini menjadi salah satu masalah utama di Indonesia, dengan penyebaran dan jumlah penderita yang cenderung meningkat setiap tahun.\r\n\r\nSepanjang 2017, diketahui ada sekitar 59.000 kasus demam berdarah di seluruh Indonesia, dengan lebih dari 400 kasus di antaranya berakhir dengan kematian. Karena jumlah penduduknya yang juga banyak, Provinsi Jawa Tengah dan Jawa Timur, menyumbang kasus DBD terbanyak untuk tahun 2017, yaitu lebih dari 7000 kasus di masing-masing provinsi.', 'demam', 'dbd.jgp'),
(5, 'JP0005', 'Edema paru', 'Edema paru adalah suatu kondisi yang ditandai dengan gejala sulit bernapas akibat terjadinya penumpukan cairan di dalam kantong paru-paru (alveoli). Kondisi ini dapat terjadi tiba-tiba maupun berkembang dalam jangka waktu lama.\r\n\r\nDalam kondisi normal, udara akan masuk ke dalam paru-paru ketika bernapas. Namun, pada kondisi edema paru, paru-paru justru terisi oleh cairan. Sehingga oksigen yang dihirup pun tidak mampu masuk ke paru-paru dan aliran darah.', 'paru-paru', 'edema.jpg'),
(6, 'JP0006', 'Flu', 'Flu merupakan penyakit yang mudah menular ke orang lain, terutama pada 3-4 hari pertama setelah penderita terinfeksi. Bahkan pada beberapa kasus, penderita flu dapat menularkan penyakitnya sebelum gejala muncul.\r\nPenyebab Flu\r\n\r\nSeseorang dapat tertular flu jika tidak sengaja menghirup percikan air liur di udara, yang dikeluarkan penderita ketika bersin atau batuk. Selain itu, menyentuh mulut atau hidung setelah memegang benda yang terkena percikan air liur penderita, juga bisa menjadi sarana penularan virus flu.', 'demam, pilek', 'flu.jpg'),
(7, 'JP0007', 'Gagal ginjal', 'Ginjal adalah sepasang organ yang berlokasi di bagian bawah punggung Anda. Satu ginjal pada setiap sisi tulang belakang Anda. Fungsi ginjal adalah menyaring darah dan mengeluarkan racun dari dalam tubuh. Ginjal mengirimkan racun ke kandung kemih yang kemudian akan dikeluarkan tubuh melalui urine saat buang air kecil.\r\n\r\nPenyakit gagal ginjal adalah kondisi yang terjadi ketika ginjal Anda kehilangan kemampuan untuk menyaring zat sisa dari darah dengan baik.', 'ginjal', 'ginjal.jpg'),
(8, 'JP0008', 'Hematuria', 'Hematuria adalah kencing berdarah. Darah di dalam urine ini dapat disebabkan oleh berbagai penyakit, mulai dari infeksi saluran kemih, penyakit ginjal, hingga kanker prostat.\r\n\r\nDarah di dalam urine akan mengubah warna urine menjadi kemerahan atau sedikit kecokelatan. Urine yang normal seharusnya tidak mengandung darah sedikitpun, kecuali pada wanita yang sedang menstruasi.\r\nHematuria umumnya tidak terasa sakit, tapi jika darah yang muncul berupa gumpalan, dapat menyumbat saluran kemih dan menimbulkan rasa sakit. Untuk mencegah terjadinya komplikasi yang berbahaya, segera periksakan diri Anda ke dokter jika mengalami kencing berdarah.', 'urine', 'darah.jpg'),
(9, 'JP0009', 'Insulinoma', 'Insulinoma adalah tumor yang tumbuh di pankreas. Pankreas merupakan organ di sistem pencernaan yang memproduksi hormon insulin. Insulin dibutuhkan oleh tubuh untuk mengatur kadar gula di dalam darah. Pada kondisi normal, pankreas membuat insulin hanya ketika tubuh membutuhkannya. Produksi insulin akan meningkat saat kadar gula (glukosa) tinggi di dalam darah, dan akan menurun bila kadar glukosa rendah.\r\nNamun pada penderita insulinoma, insulin terus diproduksi oleh pankreas tanpa dipengaruhi oleh kadar glukosa di dalam darah. Kondisi ini dapat mengakibatkan hipoglikemia (kadar glukosa di bawah batas normal), dengan gejala berupa pusing, penglihatan kabur, hingga menurunnya kesadaran.\r\n\r\nInsulinoma tergolong tumor yang jarang terjadi dan penanganannya dilakukan melalui operasi untuk mengangkat tumor. Setelah tumor penyebab insulinoma dihilangkan, maka kondisi kesehatan penderita akan pulih.', 'tumor', 'insulinoma.jpg'),
(10, 'JP0010', 'Jerawat', 'Jerawat adalah masalah kulit yang terjadi ketika folikel rambut atau tempat tumbuhnya rambut tersumbat oleh minyak dan sel kulit mati. Kondisi ini umumnya ditandai dengan munculnya bintik-bintik pada beberapa bagian tubuh, seperti wajah, leher, punggung, dan dada.\r\nMeski jerawat dapat dialami oleh siapa saja, namun sebagian besar kasus jerawat terjadi di masa puber, yaitu pada remaja berusia 10-13 tahun, dan semakin buruk pada orang dengan kulit berminyak.\r\n\r\nJerawat pada remaja umumnya akan hilang dengan sendirinya pada awal usia 20 tahun. Namun pada sebagian kasus, masih ada yang mengalami masalah jerawat hingga usia 30 tahun, terutama wanita.', 'kulit', 'jerawat.jpg'),
(11, 'JP0011', 'Kalazion', 'Kalazion adalah pembengkakan atau benjolan kecil yang muncul di kelopak mata akibat penyumbatan kelenjar meibom atau kelenjar minyak. Kalazion biasanya muncul di kelopak mata bagian atas, namun juga dapat muncul di kelopak mata bagian bawah atau bahkan kedua mata. Benjolan biasanya berukuran kecil sekitar 2-8 milimeter. Kalazion dapat hilang tanpa penanganan khusus.\r\n\r\nTerkadang, jumlah benjolan yang tumbuh di kelopak mata bisa lebih dari satu, sehingga kelopak mata terlihat mengalami pembengkakan yang tidak merata. Kondisi ini disebut dengan kalazia.', 'mata', 'kalazion.jpg'),
(12, 'JP0012', 'Liver', 'Penyakit hati atau penyakit liver adalah penyakit yang disebabkan oleh berbagai faktor yang merusak hati, seperti virus dan penggunaan alkohol. Obesitas juga berhubungan dengan kerusakan hati. Seiring waktu, kerusakan hati berdampak pada luka di jaringan (sirosis), yang dapat menyebabkan gagal hati, suatu kondisi yang mengancam jiwa.\r\n\r\nDikutip dari Mayo Clinic, hati adalah organ yang bekerja paling keras di dalam tubuh. Berukuran seperti bola yang berada tepat di bawah tulang rusuk di sisi kanan perut Anda.\r\n\r\nOrgan tersebut terdiri dari dua bagian, yaitu lobus kiri dan lobus kanan. Hati penting untuk mencerna makanan, menyingkirkan tubuh kita dari zat beracun dan menyimpan energi bagi tubuh untuk digunakan bila diperlukan.', 'pencernaan', 'liver.jpg'),
(13, 'JP0013', 'Malaria', 'Malaria adalah penyakit infeksi menular yang menyebar melalui gigitan nyamuk. Penderita malaria akan mengeluhkan gejala demam dan menggigil.\r\n\r\nWalaupun mudah menular melalui gigitan nyamuk, malaria bisa sembuh secara total bila ditangani dengan tepat. Namun jika tidak ditangani, penyakit ini bisa berakibat fatal dari menyebabkan anemia berat, gagal ginjal, hingga kematian.\r\nDi Indonesia, jumlah penderita malaria cenderung menurun dari tahun ke tahun. Namun, beberapa provinsi di Indonesia masih banyak yang menderita malaria, terutama di wilayah timur Indonesia, yaitu Papua dan Papua Barat. Sementara itu, provinsi DKI Jakarta dan Bali sudah masuk ke dalam kategori provinsi bebas malaria.', 'gigitan nyamuk', 'malaria.jpg'),
(14, 'JP0014', 'Neuropati', 'Neuropati adalah istilah yang digunakan untuk gejala gangguan atau penyakit pada saraf di tubuh. Gejala yang muncul bisa berupa nyeri, kesemutan, kram otot, hingga susah buang air kecil.\r\n\r\nPenyebab neuropati bermacam-macam, bisa berupa cedera atau penyakit tertentu, seperti diabetes. Gangguan ini juga bisa terjadi sejak lahir. Oleh karena itu, pengobatan untuk neuropati juga akan disesuaikan dengan penyebabnya.\r\nGejala Neuropati\r\nGejala neuropati berbeda-beda, tergantung pada jenis, jumlah, dan area saraf yang terganggu. Neuropati terdiri dari beberapa jenis, antara lain mononeuropati (gangguan pada satu saraf), mononeuritis multiple (gangguan pada dua saraf atau lebih di area yang berbeda), dan polineuropati (gangguan pada banyak saraf).', 'saraf', 'neuropati.jpg'),
(15, 'JP0015', 'Osteofit', 'Osteofit atau bone spur adalah tulang yang tumbuh menonjol di sekitar persendian atau tempat pertemuan antara dua tulang. Keadaan yang sering juga disebut pengapuran ini, terjadi secara perlahan dan seringkali tidak menimbulkan gejala, serta sebagian besar dialami oleh orang berusia di atas 60 tahun. Namun, osteofit juga dapat dialami oleh orang yang lebih muda akibat cedera atau kondisi medis tertentu. Osteofit dapat tumbuh di tulang manapun, tetapi paling sering terjadi di area leher, bahu, lutut, punggung bawah, kaki atau tumit, dan jari-jari\r\n\r\n', 'tulang', 'osteofit.jpg'),
(16, 'JP0016', 'Paratifus', 'Paratifus adalah penyakit infeksi bakteri yang menyerang usus dan aliran darah. Penyakit paratifus memiliki gejala yang mirip dengan dengan penyakit tifus, namun lebih ringan, jarang menimbulkan komplikasi, dan dapat lebih cepat sembuh bila dibandingkan dengan tifus.\r\n\r\nTidak hanya gejala, penyakit paratifus juga memiliki cara penularan yang sama dengan penyakit tifus, yaitu melalui konsumsi makanan atau minuman yang sudah terkontaminasi tinja orang yang terinfeksi bakteri, baik infeksi akut maupun kronik yang tidak bergejala (karier). Hubungan seksual sesama jenis juga bisa menjadi penyebab paratifus, walaupun kasusnya tergolong sangat sedikit.', 'pencernaan', 'paratifus.jpg'),
(17, 'JP0017', 'Radang tenggorokan', 'Sakit Radang tenggorokan dapat dialami semua usia, baik anak-anak maupun orang dewasa. Sakit tenggorokan karena infeksi virus adalah yang paling sering terjadi, dan biasanya dapat pulih dengan sendirinya dalam waktu satu minggu. Sebaliknya, sakit tenggorokan karena infeksi bakteri perlu diobati.\r\nSakit tenggorokan dapat menjadi gejala dari penyakit berikut ini:\r\n\r\nTonsilitis, yaitu peradangan pada amandel atau tonsil.\r\nFaringitis, yaitu peradangan pada saluran yang menghubungkan hidung atau mulut dengan kerongkongan (esofagus) atau saluran tempat pita suara (laring).\r\nLaringitis, yaitu peradangan pada laring.', 'tenggorokan', 'radang.jpg'),
(18, 'JP0018', 'Sariawan', 'Sariawan yang dalam istilah medis disebut stomatitis aftosa (apthous stomatitis) atau canker sore adalah luka di dalam mulut yang dapat menimbulkan rasa sakit dan tidak nyaman. Luka tersebut bisa berbentuk oval atau bulat, dan berwarna putih atau kuning dengan tepiannya yang berwarna merah akibat peradangan.\r\n\r\nLokasi sariawan dapat terjadi di bagian dalam pipi atau bibir, serta di permukaan gusi dan lidah. Sariawan yang tumbuh dapat berjumlah satu atau lebih. Sariawan umumnya bukan termasuk penyakit yang dapat menular. Namun pada beberapa kasus, luka sariawan bisa disebabkan oleh infeksi virus.', 'infeksi', 'sariawan.jpg'),
(19, 'JP0019', 'TBC', 'TBC (Tuberkulosis) yang juga dikenal dengan TB adalah penyakit paru-paru akibat kuman Mycobacterium tuberculosis. TBC akan menimbulkan gejala berupa batuk yang berlangsung lama (lebih dari 3 minggu), biasanya berdahak, dan terkadang mengeluarkan darah.\r\n\r\nKuman TBC tidak hanya menyerang paru-paru, tetapi juga bisa menyerang tulang, usus, atau kelenjar. Penyakit ini ditularkan dari percikan ludah yang keluar penderita TBC, ketika berbicara, batuk, atau bersin. Penyakit ini lebih rentan terkena pada seseorang yang kekebalan tubuhnya rendah, misalnya penderita HIV.', 'paru-paru', 'tbc.jpg'),
(20, 'JP0020', 'Ulkus kornea', 'Ulkus kornea adalah luka terbuka yang terjadi pada kornea. Kondisi ini biasanya terjadi akibat infeksi. Bahkan cedera kecil pada mata atau erosi akibat mengenakan lensa kontak terlalu lama pun dapat menyebabkan infeksi.\r\nKondisi ini sangat umum terjadi terjadi dan dapat menyerang pasien dengan usia berapapun. Ulkus kornea dapat ditangani dengan mengurangi faktor-faktor risiko. Diskusikan dengan dokter untuk informasi lebih lanjut.\r\nSemua gejala dari ulkus kornea serius dan harus segera diatasi untuk mencegah kebutaan.\r\n\r\nKemungkinan ada tanda-tanda dan gejala yang tidak disebutkan di atas. Bila Anda memiliki kekhawatiran akan sebuah gejala tertentu, konsultasikanlah dengan dokter Anda.', 'mata', 'kornea.jpg'),
(21, 'JP0021', 'Vertigo', 'Vertigo adalah sebuah keadaan di mana penderitanya merasa seolah-olah lingkungan di sekitarnya berputar atau melayang. Kondisi ini juga akan membuat penderitanya kehilangan keseimbangan, sehingga kesulitan untuk sekadar berdiri atau bahkan berjalan. Cara terbaik untuk menggambarkan vertigo adalah dengan memutar tubuh Anda beberapa kali dan merasakan kondisi yang dihasilkan.\r\n\r\nPerlu diketahui, vertigo bukanlah nama penyakit. Namun, sebuah kumpulan gejala yang bisa terjadi secara tiba-tiba atau berlangsung selama jangka waktu tertentu dalam satu waktu.', 'kepala', 'vertigo.jpg'),
(22, 'JP0022', 'Williams Syndrome', 'Williams syndrome atau sindrom Williams adalah penyakit genetik langka yang menyebabkan gangguan pertumbuhan dan perkembangan pada anak. Sindrom Williams biasanya ditandai dengan adanya kelainan pada wajah, pembuluh darah, dan gangguan pertumbuhan pada anak.\r\n\r\nSeorang anak berisiko menderita sindrom Williams jika salah satu atau kedua orang tuanya menderita sindrom Williams. Meski demikian, seorang anak juga dapat menderita Sindrom Williams meski kedua orang tuanya tidak menderita penyakit ini.\r\nPada banyak kasus, anak yang menderita sindrom Williams memerlukan penanganan dari dokter seumur hidup. Namun dengan pengobatan yang tepat, penderita sindrom Williams tetap dapat hidup normal seperti anak-anak lainnya.', 'langka', 'william.jpg'),
(23, 'JP0023', 'Xerosis', 'Xerosis adalah istilah medis untuk kulit kering. Xerosis bisa terjadi pada lelaki maupun perempuan tanpa memandang usia, namun lansia lebih berisiko mengalaminya. Penyakit ini dapat terjadi dalam waktu singkat atau terjadi dalam waktu yang lama (kronis).\r\nXerosis banyak ditemukan pada orang-orang yang tinggal di daerah dingin dengan tingkat kelembapan yang rendah. Kondisi ini dapat dihindari dengan mengonsumsi air yang cukup setiap hari. Asupan cairan sangat diperlukan karena cairan dibutuhkan untuk memlembapkan kulit manusia agar tetap lembut dan sehat.\r\n\r\nGejala Xerosis\r\nXerosis atau kulit kering akan tampak sebagai berikut:\r\n\r\nKering, kasar, dan bersisik terutama di lengan dan tungkai.\r\nPucat, kusam, dan berwarna keputihan.\r\nMenjadi kemerahan karena mengalami iritasi.\r\nPecah-pecah, mengelupas, dan rentan berdarah.', 'kulit', 'Xerosis.jpg'),
(24, 'JP0024', 'Zoonosis', 'Zoonosis merupakan penyakit yang disebabkan oleh organisme infeksius seperti virus, bakteri, dan parasit yang dapat ditularkan dari hewan ke manusia, atau sebaliknya. Flu burung, adalah satu dari sekian penyakit yang ditularkan dari hewan ke manusia.', 'langka', 'zoonosis.jpg'),
(25, 'JP0025', 'Sakit Hati', 'Tidak terlihat, tetapi terasa menyakitkan.', 'cinta', 'tetesan-darah-png-4.png');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id_status` int(11) NOT NULL,
  `nama` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id_status`, `nama`) VALUES
(1, 'Aktif'),
(2, 'Non-Aktif');

-- --------------------------------------------------------

--
-- Table structure for table `tb_gambar`
--

CREATE TABLE `tb_gambar` (
  `id_logo` int(3) NOT NULL,
  `logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_gambar`
--

INSERT INTO `tb_gambar` (`id_logo`, `logo`) VALUES
(1, 'logoapotek.png');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kategori`
--

CREATE TABLE `tb_kategori` (
  `id_kategori` int(11) NOT NULL,
  `kategori` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kategori`
--

INSERT INTO `tb_kategori` (`id_kategori`, `kategori`) VALUES
(1, 'Barang'),
(2, 'Kendaraan'),
(3, 'Kost');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pesan`
--

CREATE TABLE `tb_pesan` (
  `id_pesan` int(11) NOT NULL,
  `j_item` varchar(11) NOT NULL,
  `nama_penyewa` varchar(50) NOT NULL,
  `hrg_sewa` float NOT NULL,
  `telp` varchar(13) NOT NULL,
  `tgl_awal` date NOT NULL,
  `tgl_akhir` date NOT NULL,
  `total_harga` float NOT NULL,
  `id_kamar` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_slide`
--

CREATE TABLE `tb_slide` (
  `id_slide` int(11) NOT NULL,
  `title` text NOT NULL,
  `textslide` text NOT NULL,
  `slide` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_slide`
--

INSERT INTO `tb_slide` (`id_slide`, `title`, `textslide`, `slide`) VALUES
(1, 'Selamat Datang, Di ApotekMAT', 'We Care About Your Health', 'slider.png'),
(2, 'Selamat Datang, Di ApotekMAT', 'TO LIVE A HEALTHY LIFE', 'slider2.png');

-- --------------------------------------------------------

--
-- Table structure for table `tb_transaksi`
--

CREATE TABLE `tb_transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `tgl_penjualan` date NOT NULL,
  `pelanggan` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `status` varchar(255) NOT NULL,
  `resep` text NOT NULL,
  `jenis_obat` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `nama_obat` varchar(255) NOT NULL,
  `harga_jual` float NOT NULL,
  `jumlah` int(11) NOT NULL,
  `total_pembelian` float NOT NULL,
  `dibayar` float NOT NULL,
  `kembalian` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tips`
--

CREATE TABLE `tips` (
  `id_tips` int(11) NOT NULL,
  `judul` text NOT NULL,
  `isi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tips`
--

INSERT INTO `tips` (`id_tips`, `judul`, `isi`) VALUES
(1, 'Perbanyak konsumsi air putih', 'Tahukah Anda bahwa sebagian besar dari kita sebenarnya seringkali kurang minum cukup air setiap hari? Ini tentu hal yang tidak baik sebab seperti kita ketahui air sangat penting bagi tubuh kita. Ini karena kita kehilangan air setiap hari melalui urine, buang air besar, keringat dan pernapasan, sehingga kita perlu mengisi asupan air kita. Sebuah penelitian menunjukkan jumlah air yang kita butuhkan adalah tergantung pada berbagai faktor.\r\n\r\nSeperti kondisi iklim dan cuaca, aktivitas fisik yang kita lakukan, dan berat badan, tetapi umumnya kita perlu 2,7-3,7 liter asupan air. Jika muncul tanda2 seperti misalnya; urine berwarna atau agak kuning, bibir kering, mulut kering dan sedikit buang air kecil. Segeralah minum air karena itu tanda-tanda yang muncul karena tubuh mulai kekurangan cairan.'),
(2, 'Tidur dan beristirahatlah yang cukup', 'Tidur dan istirahat yang cukup adalah salah satu kunci dari kebiasaan hidup yang sehat. Ini sangat beralasan sebab tubuh sangat membutuhkan istirahat untuk dapat beraktifitas kembali dengan maksimal. Tetapi bila tidak beristirahat dengan baik, Anda bisa mengkompensasi dengan makan lebih banyak, tetapi ini sangat tidak direkomendasikan oleh para ahli kesehatan. Cukup istirahat dan tidur juga mencegah penuaan dini.'),
(3, 'Meditasi', 'Meditasi menenangkan pikiran dan menenangkan jiwa. Ketenangan sendiri sangat bermanfaat untuk kesehatan karena dapat menjauhkan kita dari stress yang menjadi sumber dari banyak penyakit dan gangguan kesehatan.'),
(4, 'Berolahraga Teratur', 'Penelitian telah menunjukkan bahwa berolahraga setiap hari membawa manfaat luar biasa bagi kesehatan kita, termasuk peningkatan rentang hidup, menurunkan risiko penyakit, kepadatan tulang yang lebih tinggi dan penurunan berat badan. Jika tidak punya waktu untuk berolahraga atau pergi ke pusat kebugaran, berjalan kaki atau aktifitas sehari-hari seperti memilih untuk naik tangga dan buka lift akan menjadi aktifitas pengganti olahraga yang mudah dan murah.'),
(5, 'Lakukan olahraga sebagai bagian dari kesenangan', 'Ketika menikmati olahraga, Anda akan secara alami ingin melakukannya. Sebab olahraga yang terpaksa akan menimbulkan penderitaan yang alih-alih menyebabkan Anda ingin terus melakukannya tetapi malah menjadi malas. Jadi pilih olahraga yang disenangi dan lakukanlah rutin.'),
(6, 'Berolahragalah seperti bermain', 'Latihan kardio saja seperti misalnya jogging akan membuat penat dan bosan. Berikan tubuh lebih banyak olahraga yang menyenangkan dan berkelompok, seperti misalnya basket, sepak bola, renang, tenis, badminton atau voli dan masih banyak yang lain. Ini akan menyenangkan karena Anda sekaligus juga dapat bersosialisasi dengan orang lain sembari melakukan aktivitas yang sehat.'),
(7, 'Makan lebih banyak buah', 'Makanlah lebih banyak buah dan kurangi vitamin sintetis. Ada banyak jenis buah yang dapat dikonsumsi yang selain menyehatkan juga rasanya dijamin enak.'),
(8, 'Makan lebih banyak sayuran', 'Seperti halnya buah-buahan, sayuran penting untuk kesehatan kita. Para ahli menyarankan bahwa kita setidaknya harus mengkonsumsi 5-9 porsi buah-buahan / sayuran, setiap harinya. Kabar buruknya adalah kebanyakan orang kurang menyenangi untuk mengkonsumsi sayuran, dan ini tentu adalah hal yang tidak baik untuk kesehatan kita.'),
(9, 'Pilih makanan berwarna cerah sebagai antioksidan', ' Buah-buahan dan sayuran dengan warna-warna cerah biasanya tinggi dalam anti-oksidan. Anti-oksidan sangat diperlukan oleh tubuh karena mereka menghilangkan dan menangkal radikal bebas dalam tubuh kita yang bisa merusak sel-sel tubuh kita.\r\n\r\nJadi mungkin Anda perlu untuk mulai mengkonsumsi sayur dan buah dengan warna-warna yang berbeda, seperti misalnya; putih (Pisang, jamur), Kuning(Nanas, Mangga), Oranye (Jeruk, Pepaya), Merah(Apel, Stroberi, Tomat, Semangka), Hijau (Jambu, Alpukat, mentimun, Selada, Seledri), Ungu/Biru (Buah Berry, Terong, Buah Plum). Diet Warna ini juga baik menjaga diet yang menyehatkan serta membentuk tubuh ideal'),
(10, 'Kurangi makanan olahan dan makanan dalam kaleng', 'Makanan  olahan atau kalengan sebaiknya dihindari karena berbagai alasan seperti misalnya; nilai gizi yang sering tidak sempurna, adanya pengawet yang ditambahkan yang dapat berdampak buruk bagi kesehatan, jika dikonsumsi terus menerus dan dalam jangka waktu panjang. Bahkan juga penambahan garam yang harus dipertimbangkan sebelum mengkonsumsi makanan olahan atau kalengan terlalu sering.'),
(11, 'Mulailah mencintai diri sendiri', 'Dengan mencintai diri sendiri Anda akan terhindar dari dampak buruk stres yang dapat berakibat buruk juga bagi kesehatan. Selain itu Anda juga dapat mengambil lebih banyak manfaat dengan pemikiran positif terhadap cara pandang tentang hidup dan kehidupan yang lebih luas yang tentu menjadikan anda pribadi yang lebih bahagia setiap harinya.'),
(12, 'Berjalan dengan Bertelanjang Kaki', 'Ada banyak manfaat yang terbukti positif berjalan dengan bertelanjang kaki berjalan mulai dari dapat memperbaiki postur tubuh lebih baik, mengurangi stres untuk kaki dan sendi. Ini sungguh beralasan ilmiah karena berjalan dengan bertelanjang kaki memberikan efek pijatan yang menciptakan rasa nyaman ke sekujur badan.');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `no_telp` varchar(14) NOT NULL,
  `password` varchar(40) NOT NULL,
  `pass` varchar(40) NOT NULL,
  `level` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama_user`, `username`, `email`, `no_telp`, `password`, `pass`, `level`) VALUES
(1, 'admin', 'admin', 'admin@gmail.com', '6287869966215', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id_contact`);

--
-- Indexes for table `data_profilweb`
--
ALTER TABLE `data_profilweb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jenis_penyakit`
--
ALTER TABLE `jenis_penyakit`
  ADD PRIMARY KEY (`id_jp`);

--
-- Indexes for table `obat`
--
ALTER TABLE `obat`
  ADD PRIMARY KEY (`id_obat`);

--
-- Indexes for table `penyakit`
--
ALTER TABLE `penyakit`
  ADD PRIMARY KEY (`id_penyakit`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id_status`);

--
-- Indexes for table `tb_gambar`
--
ALTER TABLE `tb_gambar`
  ADD PRIMARY KEY (`id_logo`);

--
-- Indexes for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `tb_pesan`
--
ALTER TABLE `tb_pesan`
  ADD PRIMARY KEY (`id_pesan`);

--
-- Indexes for table `tb_slide`
--
ALTER TABLE `tb_slide`
  ADD PRIMARY KEY (`id_slide`);

--
-- Indexes for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indexes for table `tips`
--
ALTER TABLE `tips`
  ADD PRIMARY KEY (`id_tips`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id_contact` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `data_profilweb`
--
ALTER TABLE `data_profilweb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jenis_penyakit`
--
ALTER TABLE `jenis_penyakit`
  MODIFY `id_jp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `obat`
--
ALTER TABLE `obat`
  MODIFY `id_obat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `penyakit`
--
ALTER TABLE `penyakit`
  MODIFY `id_penyakit` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `id_status` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_gambar`
--
ALTER TABLE `tb_gambar`
  MODIFY `id_logo` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_pesan`
--
ALTER TABLE `tb_pesan`
  MODIFY `id_pesan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_slide`
--
ALTER TABLE `tb_slide`
  MODIFY `id_slide` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tips`
--
ALTER TABLE `tips`
  MODIFY `id_tips` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
